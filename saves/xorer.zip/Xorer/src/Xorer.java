import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;


public class Xorer {
	//private static final int BUFFER = 2048;

	private static void xorZ0r(File current,File outputdir) throws Exception {
		ReadableByteChannel rbc = Channels.newChannel(new XorInputStream(new FileInputStream(current)));
		FileChannel fch = new FileOutputStream(outputdir).getChannel();
		fch.transferFrom(rbc, 0, Long.MAX_VALUE);
		rbc.close();
		fch.close();
	}
	public static void main(String[] args) {
		try {
			if (args.length>0) {
			xorZ0r(new File(args[0]), new File(args[1]));
			} else {
				System.out.println("ny�d");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
