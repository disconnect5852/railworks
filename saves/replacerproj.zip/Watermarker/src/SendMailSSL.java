import java.io.File;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;


public class SendMailSSL {
	private static final Logger log=Logging.getInstance();
	private static final String usr="txsanyix@gmail.com";
	private static final String psw="iMB?JVB=0*Pate2b5dx/f@RxSMYh4X";
	
	public static void SendMail(String to, File filename) {
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
 
		Session session = Session.getDefaultInstance(props,
			new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(usr,psw);
				}
			});
 
		try {
 
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("txsanyix@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			message.setSubject("Testing Subject");
			MimeBodyPart mbp1 = new MimeBodyPart();
			mbp1.setText("Dear Mail Crawler," +"\n\n No spam to my email, please!");
			MimeBodyPart mbp2 = new MimeBodyPart();
			FileDataSource fds = new FileDataSource(filename);
			mbp2.setDataHandler(new DataHandler(fds));
			mbp2.setFileName(fds.getName());
			Multipart mp = new MimeMultipart();
			mp.addBodyPart(mbp1);
			mp.addBodyPart(mbp2);
			message.setContent(mp);
			message.setSentDate(new Date());
			Transport.send(message);
			System.out.println("sent");
			log.log(Level.INFO,"Mail sent to:"+to);
		} catch (MessagingException e) {
			e.printStackTrace();
			log.log(Level.SEVERE,e.getMessage() );
		}
	}
	public static void getMails() {
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
			try {
				Session session = Session.getDefaultInstance(props, null);
				Store store = session.getStore("imaps");
				store.connect("imap.gmail.com", usr, psw);
				System.out.println(store);

				Folder inbox = store.getFolder("payment");
				inbox.open(Folder.READ_ONLY);
				FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.SEEN), true);
				Message messages[] = inbox.search(ft);
				for(Message message:messages) {
				System.out.println(message);
				if (message.getContent() instanceof Multipart) {
					Multipart multipart = (Multipart) message.getContent();
					System.out.println(multipart.getBodyPart(0).getContent());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	public static void main(String[] args) {
		//SendMail("kokszalami@t-online.hu", new File("e:/M62 turb� �j.wav"));
		getMails();
	}
}
