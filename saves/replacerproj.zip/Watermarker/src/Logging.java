import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class Logging {
	private static Logging thisLogger;
	private static final String logPath="./injector.log";
	private static Logger logger;
	
	public static Logger getInstance() {
		if(thisLogger==null) {
			thisLogger=new Logging();
		}
		return logger;
	}
	
	 private Logging() {
		super();
		logger = Logger.getLogger("MyLog");
	    FileHandler fh;

	    try {

	      // This block configure the logger with handler and formatter
	      fh = new FileHandler(logPath, true);
	      logger.addHandler(fh);
	      SimpleFormatter formatter = new SimpleFormatter();
	      fh.setFormatter(formatter);
	      logger.setLevel(Level.INFO);
	      logger.log(Level.INFO,"Logger Started");
	      logger.setLevel(Level.INFO);

	      // the following statement is used to log any messages   

	    } catch (SecurityException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	}


		}
