import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import au.com.bytecode.opencsv.CSVReader;


public class WaterMarker {
	private static final String PROPLOC="watermarker.cfg";
	private static final Properties props = new Properties();
	private static final Logger log=Logging.getInstance();
	
	public WaterMarker() {
		super();
		File propfil= new File(PROPLOC);
		try {
			if (!propfil.exists()) {
					props.put("SampleKey", "Sample data");
					props.store(new FileOutputStream(propfil),"Watermarker Config");
					log.log(Level.SEVERE,"No config file found! Write one!" );
					System.exit(0);
			}
			props.load(new FileInputStream(propfil));
			if (props.size()!=5) {
				log.log(Level.SEVERE,"Not valid config file!" );
				System.out.println(props.getProperty("transactionsCSV"));
				//System.exit(0);
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,"Something bad happened at loading config file!" );
			e.printStackTrace();
			System.exit(0);
		}
	}
	private void digestCSV() {
		List<String[]> transactions=new ArrayList<>();
		try {
			CSVReader reader = new CSVReader(new FileReader(props.getProperty("transactionsCSV")));
			transactions=reader.readAll();
		} catch (Exception e) {
			log.log(Level.SEVERE,"Error at reading CSV file!" );
			e.printStackTrace();
			System.exit(0);
		}
		for (String[] transaction: transactions) {
			
		}
		
	}
	public static void main(String[] args) {
		new WaterMarker();

	}

}
