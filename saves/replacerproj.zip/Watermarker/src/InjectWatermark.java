import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.bind.DatatypeConverter;


public class InjectWatermark {
	private static final String SERZCMD="serz.exe \"";
	private static final String SERZCMD_CLOSE="\"";
	//private static final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	//private final File[] file;
	private static final String cserelendo="<Name d:type=\"cDeltaString\">02 - Default</Name>";
	private static final String cserelendo2= "<Name d:type=\"cDeltaString\">Material #0</Name>";
	private static final String csere1="<Name d:type=\"cDeltaString\">";
	private static final String csere2="</Name>";
	private static Path destPath;
	private static URI packPath;
	private static String packPathS;
	private static final Logger log=Logging.getInstance();
	//private static InjectWatermark thisObject;
	//private static Map<String, String> originalfiles=Collections.synchronizedList(new HashMap<String, String>());
	private static List<GeoFileBean> originalfiles=Collections.synchronizedList(new ArrayList<GeoFileBean>());
	//private final boolean isGeo;
	//private static final XPath XPATH=XPathFactory.newInstance().newXPath();

	public InjectWatermark(String originalpath, String destPathS, String packPath) {
		super();
		log.log(Level.INFO,"Watermarker instance creating" );
		Path dir= FileSystems.getDefault().getPath(originalpath);
		InjectWatermark.destPath= FileSystems.getDefault().getPath(destPathS);
		InjectWatermark.packPath= new File(packPath).toURI();
		InjectWatermark.packPathS=packPath;
		
		try {
		DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.xml");
			for (Path fil: stream) {
				String result="";
					result=readFileAsString(fil.toString());
				originalfiles.add(new GeoFileBean(fil.getFileName().toString(),result));
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage() );
				e.printStackTrace();
		}
	}
	public void injectAndSave (String mailAddress) {
		for (GeoFileBean current: originalfiles) {
			String temp=new String(current.getData());
			try {
				BufferedWriter out = new BufferedWriter(new FileWriter(current.getFileName()));
				MessageDigest md= MessageDigest.getInstance("SHA-1");
				md.reset();
				md.update(mailAddress.getBytes());
				String lol = new BigInteger(1,md.digest()).toString(16).toUpperCase();
				String secondary=mailAddress+"XD";
				md.update(secondary.getBytes());
				String lol2 = new BigInteger(1,md.digest()).toString(16).toUpperCase();
				log.log(Level.WARNING,"Hash for"+mailAddress+" is "+lol);
				temp=temp.replaceFirst(cserelendo, csere1+lol+csere2);
				temp=temp.replaceFirst(cserelendo2, csere1+lol2+csere2);
				out.write(temp);
				out.close();
				//System.out.println(current.getFileName());
				serzAndRename(current.getFileName());
			} catch (Exception e) {
				log.log(Level.SEVERE,e.getMessage() );
				e.printStackTrace();
				return;
			}
		}
		
	}
	private static void serzAndRename(String file) throws Exception {
			Runtime.getRuntime().exec(SERZCMD+file+SERZCMD_CLOSE).waitFor();
			Path bin=FileSystems.getDefault().getPath(file.replaceFirst(".xml", ".bin"));
			Files.move(bin, destPath.resolve(bin.getFileName().toString().replaceFirst(".bin", ".GeoPcDx")), StandardCopyOption.REPLACE_EXISTING);
			//Thread.sleep(1000);
			zipDir("taurus.rwp",packPathS);
			//Files.move(bin, destPath.resolve(bin.getFileName().toString().replaceFirst(".bin", ".GeoPcDx")), StandardCopyOption.REPLACE_EXISTING);
			/*FileInputStream in= new FileInputStream(new File("taurus.zip"));
			FileOutputStream out= new FileOutputStream("taurus.rwp");
			byte[] header= new BigInteger("046469736301", 16).toByteArray();
			
			out.write(header);
			int len;
			byte[] tmpBuf = new byte[1024];
			while ((len = in.read(tmpBuf)) > 0) {
				out.write(tmpBuf, 0, len);
			}*/
			//pack();
			//Runtime.getRuntime().exec("7za u -tzip taurus.zip "+packPath+" -r").waitFor();
			//Files.delete(FileSystems.getDefault().getPath(file));
	}
	/*private static void pack() throws Exception {
		/*Path pth=FileSystems.getDefault().getPath(packPath);
		DirectoryStream<Path> str = Files.newDirectoryStream(pth); Files.n
		for (Path fils: str) {
			System.out.println(fils);
		}*/
		
		/*try
		{
			File inFolder=new File(packPath);
			File outFolder=new File("Out.zip");
			ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFolder)));
			BufferedInputStream in = null;
			byte[] data  = new byte[1000];
			String files[] = inFolder.list();
			//DirectoryStream<Path> stream = Files.newDirectoryStream(dir);
			for (int i=0; i<files.length; i++)
			{
				in = new BufferedInputStream(new FileInputStream(inFolder.getPath() + "/" + files[i]), 1000);  
				out.putNextEntry(new ZipEntry(files[i])); 
				int count;
				while((count = in.read(data,0,1000)) != -1)
				{
					out.write(data, 0, count);
				}
				out.closeEntry();
			}
			out.flush();
			out.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log.log(Level.SEVERE,e.getMessage() );
		}
	}*/
	
	private static void zipDir(String zipFileName, String dir) throws Exception {
		File dirObj = new File(dir);
		FileOutputStream fileOutputStream = new FileOutputStream(zipFileName);
		byte[] header= new BigInteger("046469736301", 16).toByteArray();
		fileOutputStream.write(header);
		ZipOutputStream out = new ZipOutputStream(fileOutputStream);
		log.log(Level.INFO,"Creating : " + zipFileName);
		addDir(dirObj, out);
		out.close();
	}

	private static void addDir(File dirObj, ZipOutputStream out) throws IOException {
		File[] files = dirObj.listFiles();
		byte[] tmpBuf = new byte[1024];

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				addDir(files[i], out);
				continue;
			}
			FileInputStream in = new FileInputStream(files[i].getAbsolutePath());
			String relative = Paths.get(packPath.relativize(files[i].toURI()).getPath()).toString();
			//relative= relative.replaceAll("/", "\\");
			log.log(Level.INFO," Adding: " +relative);
			out.putNextEntry(new ZipEntry(relative));
			int len;
			while ((len = in.read(tmpBuf)) > 0) {
				out.write(tmpBuf, 0, len);
			}
			out.closeEntry();
			in.close();
		}
	}
	
    private static String readFileAsString(String filePath) throws java.io.IOException{
        StringBuffer fileData = new StringBuffer();
        BufferedReader reader = new BufferedReader(
                new FileReader(filePath));
        char[] buf = new char[1024];
        int numRead=0;
        while((numRead=reader.read(buf)) != -1){
            String readData = String.valueOf(buf, 0, numRead);
            fileData.append(readData);
            buf = new char[1024];
        }
        reader.close();
        return fileData.toString();
    }
	
	

	public static void main(String[] args) {
		InjectWatermark loler= new InjectWatermark("./original","./root/Assets/HUN/Taurus/RailVehicles/ES64U2","root");
		loler.injectAndSave("logfgf@fakken.hu");
	}

}
