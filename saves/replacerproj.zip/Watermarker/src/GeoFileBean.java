
public class GeoFileBean {
	private String fileName;
	private String data;
	public GeoFileBean(String fileName, String data) {
		super();
		this.fileName = fileName;
		this.data = data;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}
