import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.swing.table.AbstractTableModel;


public class Dbtablemodel extends AbstractTableModel {
	private static final long serialVersionUID = -406493429222572377L;
	private static final String[] header={"Email", "Password", "ID1", "ID2","Notifysent"};
	private List<Dbrow> list;
	private static final String SALT="GmfFdmDe3ER5D30f";
	
	public Dbtablemodel(List<Dbrow> list) {
		this.list = list;

	}
	private String md5(String s) {
	    try {
	        MessageDigest m = MessageDigest.getInstance("MD5");
	        m.update(s.getBytes(), 0, s.length());
	        BigInteger i = new BigInteger(1,m.digest());
	        return String.format("%1$032x", i);         
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    return null;
	}

	@Override
	public int getColumnCount() {
		return header.length;
	}

	@Override
	public int getRowCount() {
		return list.size();
	}

	@Override
	public Object getValueAt(int row, int column) {

		Dbrow entity= list.get(row);
		switch (column) {
	    case 0:
	    	 return entity.getEmil();
	    case 1:
	    	 return entity.getAss();
	    case 2:
	    	 return entity.getAjdi();
	    case 3:
	    	return entity.getAjdi1();
	    case 4:
	    	return entity.isNotifysent();
	    default :
		    return "";
		}
	}
	@Override
	public String getColumnName(int column) {
		return header[column];
	}
	public boolean isCellEditable(int row, int column) {
		return  true;//column<2 || column==4;
	}

	@Override
	public void setValueAt(Object aValue, int row, int column) {
		Dbrow entity= list.get(row);
		switch (column) {
	    case 0:
	    	 entity.setEmil((String) aValue);
	    	 break;
	    case 1:
	    	String value=(String) aValue;
	    	 entity.setAss(value);
	    	 entity.setAjdi(md5(value));
	    	 entity.setAjdi1(md5(value+SALT));
	    	 break;
	    case 2:
	    	 entity.setAjdi((String) aValue);
	    	 break;
	    case 3:
	    	 entity.setAjdi1((String) aValue);
	    	 break;
	    case 4:
	    	 entity.setNotifysent((boolean) aValue);
	    }
		
	}
	
	
	@Override
	public Class<?> getColumnClass(int arg0) {
		if (arg0==4)  {
			return Boolean.class;
		}
		return String.class;
	}
	public void setValuesAtRow(String email, String password, String id1, String id2,boolean notify, int row) {
		Dbrow entity= list.get(row);
		entity.setEmil(email);
		entity.setAss(password);
		entity.setAjdi(id1);
		entity.setAjdi1(id2);
		entity.setNotifysent(notify);
		fireTableDataChanged();
	}
	
	

}
