import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jdesktop.swingx.JXTable;


public class Dbmaker {

	private JFrame frame;
	private JXTable table;
	private JTextField downlink;
	private JTextField downpass;
	private Dbbean db= new Dbbean("changethis", "changethis", new NoDuplicateList<Dbrow>());
	private Dbtablemodel tablemodel= new Dbtablemodel(db.getLst());
	final JFileChooser save= new JFileChooser();
	//private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	//private static final Pattern pat= Pattern.compile(EMAIL_PATTERN);  
	private static final String password="0UmaOVXBztlq0PODj1rIEK8h1tQrFD5qFBc1praCoV4aabwFqjxEKp1lg2uNJvz9ZAshOSrHeFqLhX0lYanRxF0qAyKMSAyfalar";
	private static final AESEncrypter cri= new AESEncrypter(password);
	private static final Logger log=Logging.getInstance();
	private static final Properties props = new Properties();
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dbmaker window = new Dbmaker();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Dbmaker() {
		initialize();
		downlink.setText(db.getLink());
		downpass.setText(db.getFass());
		
		
		save.setFileSelectionMode(JFileChooser.FILES_ONLY);
		save.setMultiSelectionEnabled(false);
		save.setFileFilter(new FileNameExtensionFilter("ztp database (.ztp)","ztp"));
		try {
			props.load(new FileReader("dbmaker.cfg"));
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage() );
			e.printStackTrace();
		}
	}
	
	public boolean SendMail(String to/*, File filename*/) {
		try {
		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(props.getProperty("usr"),props.getProperty("psw"));
			}
		});


			Message message = new MimeMessage(session,new BufferedInputStream(new FileInputStream(props.getProperty("templateeml"))));
			message.setFrom(new InternetAddress(props.getProperty("usr")));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			message.setSentDate(new Date());
			Transport.send(message);
			log.log(Level.INFO,"Mail sent to:"+to);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.log(Level.SEVERE,e.getMessage() );
			return false;
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	/*private void testdata() {
			List<Dbrow> lista=db.getLst();
			String da=UUID.randomUUID().toString();;
		for (int i=0; i<2500; i++) {
			if ((i%5)==0) {
				da=UUID.randomUUID().toString();
				//System.out.println("generuj"+i);
			}
			lista.add(new Dbrow(UUID.randomUUID().toString(), da, da, UUID.randomUUID().toString(),false));
		}
	}*/
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		table = new JXTable(tablemodel);
		table.setFillsViewportHeight(true);
		//table.setModel(new Dbtablemodel(db.getLst()));
		table.setCellSelectionEnabled(true);
		JScrollPane scrollPane = new JScrollPane(table);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JButton addNewRow = new JButton("Add new row");
		addNewRow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//testdata();
				db.getLst().add(new Dbrow("email", "password", "id1", "id2",false));
				//for (int i=0; i<2500; i++) {
				//	db.getLst().add(new Dbrow(UUID.randomUUID().toString(), UUID.randomUUID().toString(), UUID.randomUUID().toString(), UUID.randomUUID().toString(),false));
				//}
				//table.setModel(new Dbtablemodel(db.getLst()));
				tablemodel.fireTableDataChanged();
				frame.setTitle("rows: "+table.getRowCount());
			}
		});
		JButton sendNotification = new JButton("Send notification mails");
		sendNotification.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			if (JOptionPane.showConfirmDialog(frame, "Have you checked the data? did you saved before, or loaded?")==JOptionPane.YES_OPTION) {
				
				for (Dbrow row: db.getLst()) {
					if (!row.isNotifysent()) {
						row.setNotifysent(SendMail(row.getEmil()));
					}
				}
			tablemodel.fireTableDataChanged();
			}
			}
		});
		
		
		frame.getContentPane().add(sendNotification, BorderLayout.SOUTH);
		panel.add(addNewRow);
		
		JLabel lblNewLabel = new JLabel("Download link");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 9));
		panel.add(lblNewLabel);
		
		downlink = new JTextField();
		downlink.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				db.setLink(downlink.getText());
			}
		});
		panel.add(downlink);
		downlink.setColumns(10);
		
		JLabel lblDownloadPassword = new JLabel("Download password");
		lblDownloadPassword.setFont(new Font("Tahoma", Font.PLAIN, 9));
		panel.add(lblDownloadPassword);
		
		downpass = new JTextField();
		downpass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				db.setFass(downpass.getText());
			}
		});
		panel.add(downpass);
		downpass.setColumns(10);
		
		JButton delrowButton = new JButton("Delete rows");
		delrowButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (JOptionPane.showConfirmDialog(frame, "Are you sure to delete the selected rows?")==JOptionPane.YES_OPTION) {
					//List<Dbrow> list= db.getLst();
					
					for (int curr: table.getSelectedRows()) {
						table.remove(curr);						
					}
					tablemodel.fireTableDataChanged();
					frame.setTitle("rows: "+table.getRowCount());
				}
			}
		});
		panel.add(delrowButton);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem openDbFile = new JMenuItem("Open db file...");
		openDbFile.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(save.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION) {
					try {
						//InflaterInputStream dos = new InflaterInputStream(cri.decryptstream(new FileInputStream(save.getSelectedFile())), new Inflater());
						DataInputStream dis= new DataInputStream(new InflaterInputStream(cri.decryptstream(new FileInputStream(save.getSelectedFile())), new Inflater()));
						db.readFromStream(dis);
						dis.close();
						tablemodel= new Dbtablemodel(db.getLst());
						table.setModel(tablemodel);
						tablemodel.fireTableDataChanged();
						downlink.setText(db.getLink());
						downpass.setText(db.getFass());
						frame.setTitle("rows: "+table.getRowCount());
					} catch (Exception e) {
						log.severe("Could not open db:"+e.getMessage());
						e.printStackTrace();
					}
				}
				
			}
		});
		mnFile.add(openDbFile);
		
		JMenuItem saveDbFile = new JMenuItem("Save db file...");
		saveDbFile.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if (save.showSaveDialog(frame)==JFileChooser.APPROVE_OPTION) {
					try {
						DeflaterOutputStream dcos = new DeflaterOutputStream(cri.encryptstream(new FileOutputStream(save.getSelectedFile())), new Deflater(Deflater.DEFAULT_COMPRESSION));
						//GZIPOutputStream gos=new GZIPOutputStream(cri.encryptstream(new FileOutputStream(save.getSelectedFile())));
						DataOutputStream dos= new DataOutputStream(dcos);
						db.writeToStream(dos);
						//System.out.println(db.getLst().size());
						dcos.finish();
						dos.close();
					} catch (Exception e) {
						log.severe("Could not save db:"+e.getMessage());
						e.printStackTrace();
					}
				}
			}
		});
		mnFile.add(saveDbFile);
		JMenuItem saveDbTo = new JMenuItem("Save db to text file");
		saveDbTo.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (save.showSaveDialog(frame)==JFileChooser.APPROVE_OPTION) {
					try {
						BufferedWriter bw= new BufferedWriter(new FileWriter(save.getSelectedFile()));
						bw.append("Email");
						bw.append(" ");
						bw.append("Pass");
						bw.append(" ");
						bw.append("ID1");
						bw.append(" ");
						bw.append("ID2");
						bw.append(" ");
						bw.append("Notifysent");
						bw.newLine();
						
						for(Dbrow drow: db.getLst()) {
							bw.append(drow.toString());
							bw.newLine();
						}
						bw.close();
						
					} catch (Exception e1) {
						log.severe("Could not save db to text:"+e1.getMessage());
						e1.printStackTrace();
					}
				}
			}
		});
		mnFile.add(saveDbTo);
		
		JMenu mnMuvvelet = new JMenu("Muvvelet");
		menuBar.add(mnMuvvelet);
		
		JMenuItem resetSelectedNotify = new JMenuItem("Reset selected notify checkboxes");
		mnMuvvelet.add(resetSelectedNotify);
		resetSelectedNotify.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				//List<Dbrow> rowsok=db.h
				for (int curr: table.getSelectedRows()) {
					table.setValueAt(false, curr, 4);
				}
			}
		});
		
		JMenuItem setSelectedNotifies = new JMenuItem("Set selected notifies true");
		setSelectedNotifies.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				for (int curr: table.getSelectedRows()) {
					table.setValueAt(true, curr, 4);
				}
			}
		});
		mnMuvvelet.add(setSelectedNotifies);
	}
	 /* public boolean validate(final String hex){
		  Matcher matcher = pat.matcher(hex);
		  return matcher.matches();
 
	  }
		public static boolean isEmptyOrBlank(String str) {
			return str == null || str.trim().isEmpty();
		}*/

}
