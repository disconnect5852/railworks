

public class geco {

   
	  public static void main(String[] args) throws Exception {
		  
		  	String fdf="dfsdkfsdjkfkjsldfkl";
		  	System.out.println(new String(fdf.getBytes()));
		    /*URL u = new URL("https://dl.dropbox.com/u/5862163/l6r8.ztp");
		    HttpURLConnection uc = (HttpURLConnection) u.openConnection();
		    int code = uc.getResponseCode();
		    String response = uc.getResponseMessage();
		    //System.out.println("HTTP/1.x " + code + " " + response);
		    for (int j = 1;; j++) {
		      String header = uc.getHeaderField(j);
		      String key = uc.getHeaderFieldKey(j);
		      if (header == null || key == null)
		        break;
		      //System.out.println(uc.getHeaderFieldKey(j) + ": " + header);
		    }
		    InputStream in = new BufferedInputStream(uc.getInputStream());

		    Reader r = new InputStreamReader(in);
		    int c;
		    while ((c = r.read()) != -1) {
		      System.out.print((char) c);
		    }*/
		  byte[] abyte = ("0UmaOVXBztlq0PODj1rIEK8h1tQrFD5qFBc1praCoV4aabwFqjxEKp1lg2uNJvz9ZAshOSrHeFqLhX0lYanRxF0qAyKMSAyfalar").getBytes();
		  StringBuilder srt=new StringBuilder();
		  for (byte baj: abyte) {
			  srt.append(baj);
			  srt.append(",");
		  }
		  System.out.println(srt.toString()+" length:"+abyte.length);
		  srt=new StringBuilder();
		  byte[] bbyte= xor(abyte);
		  for (byte baj: bbyte ) {
			  srt.append(baj);
			  srt.append(",");
		  }
		  System.out.println(srt.toString()+" length:"+bbyte.length);
		  
		  srt=new StringBuilder();
		  byte[] cbyte= xor(bbyte);
		  for (byte baj: cbyte ) {
			  srt.append(baj);
			  srt.append(",");
		  }
		  System.out.println(srt.toString()+" length:"+bbyte.length);
		  
		  }
	  private static byte[] xor(byte[] in) {
		  int gridro=4;
		  int gridco=3;
		  //byte xor= Byte.parseByte(Integer.toString((gridco*gridro)));
		  byte xor= (byte)((gridco*gridro)*7);
		  System.out.println(xor);
		  byte[] output  = new byte[in.length];
		  for (int i=0; i<in.length; i++) {
			  output[i]=(byte) (in[i] ^ xor);
		  }
		  return output;
	  }
	
}