import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class SendMailSSL {
	private static final Logger log=Logging.getInstance();
	private static final Properties props = new Properties();
	//private static BufferedInputStream emlis;
	public SendMailSSL() {
		super();
		try {
			props.load(new FileReader("dbmaker.cfg"));
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage() );
			e.printStackTrace();
		}
	}
	public boolean SendMail(String to/*, File filename*/) {
		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(props.getProperty("usr"),props.getProperty("psw"));
			}
		});

		try {

			Message message = new MimeMessage(session,new BufferedInputStream(new FileInputStream(props.getProperty("templateeml"))));
			message.setFrom(new InternetAddress(props.getProperty("usr")));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			//message.setSubject("Mit mond az 483992 kil�s ver�b?");
			//MimeBodyPart mbp1 = new MimeBodyPart();
			//mbp1.setText("Csipp csippp");
			//MimeBodyPart mbp2 = new MimeBodyPart();
			//FileDataSource fds = new FileDataSource(filename);
			//mbp2.setDataHandler(new DataHandler(fds));
			//mbp2.setFileName(fds.getName());
			//Multipart mp = new MimeMultipart();
			//mp.addBodyPart(mbp1);
			//mp.addBodyPart(mbp2);
			//message.setContent(mp);
			message.setSentDate(new Date());
			Transport.send(message);
			log.log(Level.INFO,"Mail sent to:"+to);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.log(Level.SEVERE,e.getMessage() );
			return false;
		}
	}
	/*public static void getMails() {
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
			try {
				Session session = Session.getDefaultInstance(props, null);
				Store store = session.getStore("imaps");
				store.connect("imap.gmail.com", usr, psw);
				System.out.println(store);

				Folder inbox = store.getFolder("payment");
				inbox.open(Folder.READ_ONLY);
				FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.SEEN), true);
				Message messages[] = inbox.search(ft);
				for(Message message:messages) {
				System.out.println(message);
				if (message.getContent() instanceof Multipart) {
					Multipart multipart = (Multipart) message.getContent();
					System.out.println(multipart.getBodyPart(0).getContent());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}*/
	/*public static void main(String[] args) {
		SendMail("kokszalami@t-online.hu");
		//getMails();
	}*/
}
