import java.io.InputStream;
import java.io.OutputStream;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;


public class DesEncrypter {
    Cipher ecipher;
    Cipher dcipher;

    DesEncrypter(String passPhrase) {
        try {
            // Create the key
            //KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), scho, iterationCount);
        	
            KeySpec keySpec= new DESedeKeySpec(passPhrase.getBytes());
            SecretKey key = SecretKeyFactory.getInstance("TripleDES").generateSecret(keySpec);
            ecipher = Cipher.getInstance(key.getAlgorithm());
            dcipher = Cipher.getInstance(key.getAlgorithm());

            // Prepare the parameter to the ciphers
            //AlgorithmParameterSpec paramSpec = new PBEParameterSpec(scho, iterationCount);
           // AlgorithmParameterSpec paramSpec = new DESede
            // Create the ciphers
            ecipher.init(Cipher.ENCRYPT_MODE, key);
            dcipher.init(Cipher.DECRYPT_MODE, key);
        } catch (java.security.spec.InvalidKeySpecException e) {
        	//e.printStackTrace();
        } catch (javax.crypto.NoSuchPaddingException e) {
        	//e.printStackTrace();
        } catch (java.security.NoSuchAlgorithmException e) {
        	//e.printStackTrace();
        } catch (java.security.InvalidKeyException e) {
        	//e.printStackTrace();
        }
    }
    byte[] buf = new byte[1024];
    public void encrypt(InputStream in, OutputStream out) {
        try {
            // Bytes written to out will be encrypted
            out = new CipherOutputStream(out, ecipher);

            // Read in the cleartext bytes and write to out to encrypt
            int numRead = 0;
            while ((numRead = in.read(buf)) >= 0) {
                out.write(buf, 0, numRead);
            }
            out.close();
        } catch (java.io.IOException e) {
        	//e.printStackTrace();
        }
    }

    public void decrypt(InputStream in, OutputStream out) {
        try {
            // Bytes read from in will be decrypted
            in = new CipherInputStream(in, dcipher);

            // Read in the decrypted bytes and write the cleartext to out
            int numRead = 0;
            while ((numRead = in.read(buf)) >= 0) {
                out.write(buf, 0, numRead);
            }
            out.close();
        } catch (java.io.IOException e) {
        	//e.printStackTrace();
        }
    }
    public OutputStream encryptstream(OutputStream out) {
    	return new CipherOutputStream(out, ecipher);
    }
    public InputStream decryptstream(InputStream in) {
    	return new CipherInputStream(in, dcipher);
    }
}
