import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.spec.AlgorithmParameterSpec;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.interfaces.PBEKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.unzip.UnzipUtil;


public class Installer {
	//private static final int BUFF_SIZE = 4096;
	private String email;
	private String password;
	private String destination;
	private static final String DB ="https://dl.dropbox.com/u/28503222/l6r8.ztp";
	private static final String OPTION ="https://dl.dropbox.com/u/28503222/choice.cqd";
	//private static final String DB ="http://google.com";
	//private static final String vrtML="0UmaOVXBztlq0PODj1rIEK8h1tQrFD5qFBc1praCoV4aabwFqjxEKp1lg2uNJvz9ZAshOSrHeFqLhX0lYanRxF0qAyKMSAyfalar";
	private static final byte[] iv = new byte[] 
			{ 
			0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f 
			};
	private static final byte[] ctzl={92,45,21,25,55,46,32,58,2,12,20,9,72,20,55,90,18,73,10,59,61,51,64,16,23,12,61,10,62,60,79,9,62,59,27,73,8,10,25,19,23,46,76,35,25,26,15,62,9,18,9,32,86,8,73,20,31,74,13,54,50,14,2,65,34,57,11,16,55,43,10,48,29,62,9,52,16,32,72,20,33,25,22,42,0,62,72,9,57,1,51,53,43,57,1,30,25,20,25,10};
	private static final byte[] vrtML={100,1,57,53,27,2,12,22,46,32,56,37,100,4,27,16,62,101,38,29,17,31,108,60,101,32,5,38,18,16,97,37,18,22,55,101,36,38,53,23,59,2,96,53,53,54,35,18,37,62,44,17,31,36,101,56,51,102,33,26,30,34,46,109,14,21,39,60,27,7,38,28,49,18,37,24,60,12,100,56,13,53,58,6,44,18,100,37,21,45,31,25,7,21,45,50,53,56,53,38};
	//private static final byte[] replace ="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa".getBytes();
	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static final byte[] replace=new byte[]{97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97};
	private static final byte[] salt ={18,-12,-45,88,123,1,127,12,45,5,89,61,-24,-65,34,31}; 
	private static final byte[] replace1 =new byte[]{98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98};
	private URL ziplink;
	private String ass;
	private byte[] ajdi;
	private byte[] ajdi2;
	private static final int TRANSFER_BLOCK=255000;
	private final Panel panel = new Panel();
	private static final Label progress = new Label("");
	private Cipher dcipher;
	private static int gridro=5;
	private static final Pattern pat= Pattern.compile(EMAIL_PATTERN);  
	private static int gridco=2;
	private static List<URL> options=new ArrayList<URL>();
	private static final java.awt.List CHOICE=new java.awt.List(2);
	private static final Checkbox CHECKBOX= new Checkbox("Only download the selected optional content");
	//private static byte zomp=113;


	private Installer() {
		super();
		/*this.email = email;
		this.password = password;
		this.destination = destination;*/
		final Frame frm= new Frame("FSZLM installer framework (Siemens ES64U Taurus for Train Simulator 2012)");
		final Dialog dialog=new Dialog(frm,"Error");
		dialog.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				dialog.setVisible(false);
			}
		});
		panel.setBackground(Color.ORANGE);
		frm.add(panel);
		panel.setLayout(new GridLayout(gridro, gridco, 0, 0));
		gridro++;

		Label label = new Label("Email address which you used for donation");
		//label.setMaximumSize(new Dimension(32767, 10));
		label.setAlignment(Label.RIGHT);
		panel.add(label);

		final TextField gemail = new TextField();
		gemail.setColumns(20);
		panel.add(gemail);

		Label label_1 = new Label("Password of your donation");
		label_1.setAlignment(Label.RIGHT);
		panel.add(label_1);

		final TextField gpassword = new TextField();
		gpassword.setColumns(20);
		panel.add(gpassword);
		gridco++;
		Button apply = new Button("Download");
		apply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				email=gemail.getText();
				password=gpassword.getText();
				if (!isEmptyOrBlank(email) && !isEmptyOrBlank(password)) {
				FileDialog file= new FileDialog(frm,"Please locate your TS2012 installation by finding railworks.exe", FileDialog.LOAD);
				file.setFile("Railworks.exe");
				file.setVisible(true);
				String fl= file.getFile();
				//System.out.println(file.getDirectory()+fl);
				 //&& new File(file.get fl).exists() 
				destination=file.getDirectory();
				if (fl!=null && fl.equalsIgnoreCase("Railworks.exe") && new File(destination+fl).exists()) {

						/*try {
							letsDoThis();
						} catch (FileNotFoundException e) {
							progress.setBackground(Color.RED);
							progress.setText("Database files are unreachable, check your connection, and firewall");
						} catch (net.lingala.zip4j.exception.ZipException e) {
							progress.setBackground(Color.RED);
							progress.setText("Data file is corrupted");
						} catch (java.util.zip.ZipException e) {
							progress.setBackground(Color.RED);
							progress.setText("Database file is corrupted");
						} catch (Exception e) {
							progress.setBackground(Color.RED);
							progress.setText(e.getClass()+e.getMessage());
						}*/
					Thread t= new Thread(new LetsDoThis());
					t.start();
					/*try {
						t.join();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/


				} else {
					progress.setText("You need to select Railworks.exe!");
					progress.setBackground(Color.YELLOW);
				}
				} else {
					progress.setBackground(Color.YELLOW);
					progress.setText("The email address in incorrect or the transaction ID is missing");
				}
			}
		});
		panel.add(apply);
		progress.setFont(new Font("Arial", Font.PLAIN, 9));

		panel.add(progress);
		
		Label label_2 = new Label("Select optional downloads:");
		label_2.setAlignment(Label.RIGHT);
		panel.add(label_2);
		
		try {
			BufferedReader opts= new BufferedReader(new InputStreamReader(new URL(OPTION).openStream()));
			String rawline;
			while ((rawline = opts.readLine()) != null) {
				String[] line= rawline.split(";");
				options.add(new URL(line[1]));
				//CHOICE.setMultipleSelections(true);
				CHOICE.add(line[0]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		};
		
		//ScrollPane scrollPane = new ScrollPane();
		//scrollPane.setPreferredSize(new Dimension(15,50));
		//scrollPane.setWheelScrollingEnabled(true);
		//scrollPane.setMinimumSize(new Dimension(15,100));
		CHOICE.setMultipleMode(true);
		//scrollPane.add(CHOICE);
		//panel.add(scrollPane);
		panel.add(CHOICE);
		
		//JScrollPane scrollPane = new JScrollPane();
		//scrollPane.add(CHOICE);
		//panel.add(scrollPane);
		
		//Scrollbar scrollbar = new Scrollbar();
		//panel.add(scrollbar);
		//scrollbar.add(CHOICE)
		//CHOICE.setSize(new Dimension(10, 1));
		//CHOICE.
		//panel.add(CHOICE);
		panel.add(CHECKBOX);
		//Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		//frm.setSize(dim.width/2,dim.height/2);
		frm.setVisible(true);
		frm.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
		frm.pack();
	}
	  public boolean validate(final String hex){
		  Matcher matcher = pat.matcher(hex);
		  return matcher.matches();
 
	  }
		public static boolean isEmptyOrBlank(String str) {
			return str == null || str.trim().isEmpty();
		}
	private boolean isLegit() throws MalformedURLException, IOException, FileNotFoundException {
		  byte cvwm= (byte)(56);
		  byte[] stml  = new byte[vrtML.length];
		  for (int i=0; i<vrtML.length; i++) {
			  stml[i]=(byte) (vrtML[i] ^ cvwm);
		  }
		setMausoleum();
		DataInputStream dis= new DataInputStream(new InflaterInputStream(deMausoleum(new BufferedInputStream(new URL(DB).openStream())), new Inflater()));
		ziplink=new URL(dis.readUTF());
		ass=dis.readUTF();
		try {
			while(true) {
				String[] row={dis.readUTF(),dis.readUTF(),dis.readUTF(),dis.readUTF()};
				dis.readBoolean();
				//System.out.println(email.trim() + " "+ password.trim());
				if (row[0].equalsIgnoreCase(email.trim()) && row[1].equalsIgnoreCase(password.trim())) {
					if (row[2].equals("wrz")) {
						/*DirectoryStream<Path> stream=Files.newDirectoryStream(Paths.get(destination+System.getProperty("file.separator")+"Assets"+System.getProperty("file.separator")+"HRQ"+System.getProperty("file.separator")+"Taurus"));
						for (Path file: stream) {
							System.out.println(file.toAbsolutePath());
							Files.delete(file);
							Files.walkFileTree(start, visitor)
						}*/
						removeRecursive(Paths.get(destination+System.getProperty("file.separator")+"Assets"+System.getProperty("file.separator")+"HRQ"+System.getProperty("file.separator")+"Taurus"));
						return false;
					}
					ajdi=row[2].getBytes();
					ajdi2=row[3].getBytes();
					dis.close();
					return true;
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			dis.close();
			return false;
		}
	}

	/*public static void copyInputStream(InputStream in, OutputStream out) throws IOException {
		byte[] buffer = new byte[BUFF_SIZE];
		int len = in.read(buffer);
		while (len >= 0) {
			out.write(buffer, 0, len);
			len = in.read(buffer);
		}
		in.close();
		out.close();
	}*/
	
	public static void removeRecursive(Path path) throws IOException
	{
	    Files.walkFileTree(path, new SimpleFileVisitor<Path>()
	    {
	        @Override
	        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
	                throws IOException
	        {
	            Files.delete(file);
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException
	        {
	            // try to delete the file anyway, even if its attributes
	            // could not be read, since delete-only access is
	            // theoretically possible
	            Files.delete(file);
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException
	        {
	            if (exc == null)
	            {
	                Files.delete(dir);
	                return FileVisitResult.CONTINUE;
	            }
	            else
	            {
	                // directory iteration failed; propagate exception
	                throw exc;
	            }
	        }
	    });
	}
	private Path downloadZip(URL down) throws Exception {
		progress.setText("Access granted, initializing download");
		progress.setBackground(Color.GREEN);
		//File dafile= File.createTempFile("inst", "cro");
		Path dafile= Files.createTempFile("inst", "cro");
		//dafile.deleteOnExit();
		//System.out.println(dafile.getName());
		//URL website = new URL(ziplink);
		ReadableByteChannel rbc = Channels.newChannel(new XorInputStream(/*new FileInputStream("e:/Taucucc/q37eeritunqssw.cre")*/ down.openStream()));
		FileChannel fch=FileChannel.open(dafile, StandardOpenOption.WRITE);
		long bytestransferred= fch.transferFrom(rbc, 0, TRANSFER_BLOCK);
		long totalbytestransferred=0;
		progress.setBackground(Color.GREEN);
		while (bytestransferred==TRANSFER_BLOCK) {
			totalbytestransferred=totalbytestransferred+bytestransferred;
			progress.setText("Downloaded: "+totalbytestransferred/1048576f+" mbytes");
			bytestransferred= fch.transferFrom(rbc, totalbytestransferred, TRANSFER_BLOCK);
		}
		fch.close();
		return dafile;
	}

	private void extractFiles(Path zipfile) throws Exception {
		progress.setBackground(Color.GREEN);
		progress.setText("Extracting files");
		ZipInputStream is = null;
		FileOutputStream os = null;

		// Initiate the ZipFile
		ZipFile zipFile = new ZipFile(zipfile.toFile());
		if (zipFile.isEncrypted()) {
			zipFile.setPassword(ass);
		}

		//Get a list of FileHeader. FileHeader is the header information for all the
		//files in the ZipFile

		@SuppressWarnings("rawtypes")
		List fileHeaderList = zipFile.getFileHeaders();

		// Loop through all the fileHeaders
		for (int i = 0; i < fileHeaderList.size(); i++) {
			FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
			if (fileHeader != null) {

				//Build the output file
				String outFilePath = destination + System.getProperty("file.separator") + fileHeader.getFileName();
				File outFile = new File(outFilePath);

				//Checks if the file is a directory
				if (fileHeader.isDirectory()) {
					//This functionality is up to your requirements
					//For now I create the directory
					outFile.mkdirs();
					continue;
				}

				//Check if the directories(including parent directories)
				//in the output file path exists
				File parentDir = outFile.getParentFile();
				if (!parentDir.exists()) {
					parentDir.mkdirs();
				}

				//Get the InputStream from the ZipFile
				is = zipFile.getInputStream(fileHeader);
				//Initialize the output stream

				//int readLen = -1;
				os = new FileOutputStream(outFile);
				//Loop until End of File and write the contents to the output stream
				ReadableByteChannel ch=Channels.newChannel(is);
				if (fileHeader.getFileName().toLowerCase().contains(".geopcdx")) {
					ByteBuffer bbuf = ByteBuffer.allocate((int)fileHeader.getUncompressedSize());
					int read=ch.read(bbuf);
					//byte[] buff = new byte[(int)fileHeader.getUncompressedSize()];
					//StringBuilder strb= new StringBuilder();
					//readLen = is.read(buff); 
					byte[] buff= bbuf.array();
					//System.out.println("read: "+read+" buff:"+buff.length+ " header:"+fileHeader.getUncompressedSize());
					if (1<read) {
						int index=indexOf(buff, replace);
						int index1=indexOf(buff, replace1);
						if (index>0){
							for (int j=0; j<replace.length; j++) {
								buff[index+j]=ajdi[j];
								
							}
							if (index1>0) {
								for (int j=0; j<replace1.length; j++) {
									buff[index1+j]=ajdi2[j];
								}
							}
							os.write(buff);
						}
						else {

							progress.setBackground(Color.RED);
							progress.setText("geo file extraction failed arg:"+index);
						}

					}
					//InputStream ris= new ReplacingInputStream(is, "01 - Default".getBytes(), "lol".getBytes());
					/*byte[] buff = new byte[BUFF_SIZE];
							while ((readLen = is.read(buff)) != -1) {
								os.write(buff, 0, readLen);
							}*/

				} else {
					os.getChannel().transferFrom(Channels.newChannel(is), 0, Long.MAX_VALUE);
				}
				//Please have a look into this method for some important comments
				closeFileHandlers(is, os);

				//To restore File attributes (ex: last modified file time, 
				//read only flag, etc) of the extracted file, a utility class
				//can be used as shown below
				UnzipUtil.applyFileAttributes(fileHeader, outFile);

				//System.out.println("Done extracting: " + fileHeader.getFileName());
			} else {
				System.err.println("fileheader is null. Shouldn't be here");
			}
		}

	}

	private void closeFileHandlers(ZipInputStream is, OutputStream os) throws IOException{
		//Close output stream
		if (os != null) {
			os.close();
			os = null;
		}

		//Closing inputstream also checks for CRC of the the just extracted file.
		//If CRC check has to be skipped (for ex: to cancel the unzip operation, etc)
		//use method is.close(boolean skipCRCCheck) and set the flag,
		//skipCRCCheck to false
		//NOTE: It is recommended to close outputStream first because Zip4j throws 
		//an exception if CRC check fails
		if (is != null) {
			is.close(true);
			is = null;
		}
		
	}
private class LetsDoThis implements Runnable {

	@Override
	public void run() {
		try {
			if (isLegit()) {
				//Set<Path> filz= new HashSet<Path>();
				if (!CHECKBOX.getState()) {
					Path fil= downloadZip(ziplink);
					extractFiles(fil);
					Files.delete(fil);
					progress.setText("The main files are installed successfully!");
				}
				int[] selz= CHOICE.getSelectedIndexes();
				for (int sel:selz) {
					Path fil=downloadZip(options.get(sel));
					extractFiles(fil);
					Files.delete(fil);
					progress.setText("An optional file is installed successfully!");
				}
				
				//extractFiles(fil);
				//Files.delete(fil);
				ass="FDFDFERE%EF23721873878d88728z17241782z4z87d78w8dz723";
			} else {
				//throw new Exception("Access denied. Check your password and email. If you've donated already please give us some time to process your donation.");
				progress.setBackground(Color.RED);
				progress.setText("Access denied. Check your password and email.");
			}
		} catch (FileNotFoundException e) {
			progress.setBackground(Color.RED);
			progress.setText("Database files are unreachable, check your connection, and firewall");
		} catch (net.lingala.zip4j.exception.ZipException e) {
			progress.setBackground(Color.RED);
			progress.setText("Data file is corrupted");
			//e.printStackTrace();
		} catch (java.util.zip.ZipException e) {
			progress.setBackground(Color.RED);
			progress.setText("Database file is corrupted");
			//e.printStackTrace();
		} catch (Exception e) {
			progress.setBackground(Color.RED);
			progress.setText(e.getClass()+e.getMessage());
		}
		
		
	
		
	}
	
}
	/*private void letsDoThis() throws Exception {
		if (isLegit()) {
			//Set<Path> filz= new HashSet<Path>();
			if (!CHECKBOX.getState()) {
				Path fil= downloadZip(ziplink);
				extractFiles(fil);
				Files.delete(fil);
				progress.setText("The main files are installed successfully!");
			}
			int[] selz= CHOICE.getSelectedIndexes();
			for (int sel:selz) {
				Path fil=downloadZip(options.get(sel));
				extractFiles(fil);
				Files.delete(fil);
				progress.setText("An optional file is installed successfully!");
			}
			
			//extractFiles(fil);
			//Files.delete(fil);
			ass="FDFDFERE%EF23721873878d88728z17241782z4z87d78w8dz723";
		} else {
			//throw new Exception("Access denied. Check your password and email. If you've donated already please give us some time to process your donation.");
			progress.setBackground(Color.RED);
			progress.setText("Access denied. Check your password and email.");
		}
		
	
	}*/

	private static int indexOf(byte[] data, byte[] pattern) {
		int[] failure = computeFailure(pattern);

		int j = 0;

		for (int i = 0; i < data.length; i++) {
			while (j > 0 && pattern[j] != data[i]) {
				j = failure[j - 1];
			}
			if (pattern[j] == data[i]) {
				j++;
			}
			if (j == pattern.length) {
				return i - pattern.length + 1;
			}
		}
		return -1;
	}

	/**
	 * Computes the failure function using a boot-strapping process,
	 * where the pattern is matched against itself.
	 */
	private static int[] computeFailure(byte[] pattern) {
		int[] failure = new int[pattern.length];

		int j = 0;
		for (int i = 1; i < pattern.length; i++) {
			while (j>0 && pattern[j] != pattern[i]) {
				j = failure[j - 1];
			}
			if (pattern[j] == pattern[i]) {
				j++;
			}
			failure[i] = j;
		}

		return failure;
	}

	/*private void setMausoleum(byte[] pss) {
		try {
			// Create the key
			//KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), scho, iterationCount);
			KeySpec keySpec= new DESedeKeySpec(pss);
			SecretKey key = SecretKeyFactory.getInstance("TripleDES").generateSecret(keySpec);
			ecipher = Cipher.getInstance(key.getAlgorithm());
			dcipher = Cipher.getInstance(key.getAlgorithm());

			// Prepare the parameter to the ciphers
			//AlgorithmParameterSpec paramSpec = new PBEParameterSpec(scho, iterationCount);
			// AlgorithmParameterSpec paramSpec = new DESede
			// Create the ciphers
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			dcipher.init(Cipher.DECRYPT_MODE, key);
		} catch (Exception e) {
			
		}
	}*/
	private void setMausoleum() {
		  byte cvwm= (byte)(84);
		  byte[] stml  = new byte[vrtML.length];
		  for (int i=0; i<vrtML.length; i++) {
			  stml[i]=(byte) (vrtML[i] ^ cvwm);
		  }

			AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv); 
			try 
			{
				//rand.nextBytes(salt);  
				//PBEKeySpec password = new PBEKeySpec(passphrase.toCharArray(), new byte[16], 1, 128);  
				//SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
				ctzl.toString();
				PBEKey key = (PBEKey) SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(new String(stml).toCharArray(), salt, 7, 128));  
				SecretKey encKey = new SecretKeySpec(key.getEncoded(), "AES"); 
				//ecipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); 
				dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); 

				// CBC requires an initialization vector 
				//ecipher.init(Cipher.ENCRYPT_MODE, encKey, paramSpec); 
				dcipher.init(Cipher.DECRYPT_MODE, encKey, paramSpec); 
			} 
			catch (Exception e) 
			{ 
				e.printStackTrace(); 
			} 
	}
    /*private OutputStream enMausoleum(OutputStream out) {
    	return new CipherOutputStream(out, ecipher);
    }*/
    private InputStream deMausoleum(InputStream in) {
    	return new CipherInputStream(in, dcipher);
    }
	public static void main(String[] args) {
		new Installer();
		/*try {
		  ReadableByteChannel rbc= Channels.newChannel(new XorInputStream(new FileInputStream("testzip.itq")));
		  FileChannel fch = new FileOutputStream("out.cor").getChannel();
		  fch.transferFrom(rbc, 0, Long.MAX_VALUE);
		  
			//DesEncrypter cri= new DesEncrypter(vrtML);
			//cri.encrypt(new FileInputStream("F:/l6r8.txt"), new FileOutputStream("F:/l6r8.ztp"));
			//cri.decrypt(new FileInputStream("F:/l6r8.ztp"), new FileOutputStream("F:/l6r8.dec"));
			//System.out.println(inst.isLegit());
			//inst.letsDoThis();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

}
