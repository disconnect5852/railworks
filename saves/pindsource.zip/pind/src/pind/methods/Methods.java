package pind.methods;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Set;
import java.util.TreeSet;

public class Methods {
	private static Methods instance=null;
	private Set<String> list;

	private Methods() {
		super();
		list=new TreeSet<String>();
	}
	public static Methods getInstance() {
	      if(instance == null) {
	          instance = new Methods();
	       }
	       return instance;
	}
	
	
	public Set<String> getList() {
		return list;
	}


	public void setList(Set<String> list) {
		this.list = list;
	}


	public void loadLineSep(Path file) throws IOException {
		BufferedReader br= Files.newBufferedReader(file, Charset.defaultCharset());
		String s;
		while ((s = br.readLine()) != null) {
			list.add(s.toLowerCase());
			//System.out.println(s);
		}
		br.close();
	}
	public void loadSpaceSep(Path file) throws IOException {
		BufferedReader br= Files.newBufferedReader(file, Charset.defaultCharset());
		String s;
		while ((s = br.readLine()) != null) {
			for (String element : s.toLowerCase().split(" ")) {
				list.add(element);
			}
		}
		br.close();
	}
	public void saveLineSep(Path file) throws IOException {
		BufferedWriter bw= Files.newBufferedWriter(file, Charset.defaultCharset(), StandardOpenOption.CREATE);
		for (String element : list) {
			bw.write(element);
			bw.newLine();
		}
		bw.close();
	}
	public void saveSpaceSep(Path file) throws IOException {
		BufferedWriter bw= Files.newBufferedWriter(file, Charset.defaultCharset(), StandardOpenOption.CREATE);
		for (String element : list) {
			bw.write(element+" ");
		}
		bw.close();
	}
	
}
