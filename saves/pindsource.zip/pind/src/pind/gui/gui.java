package pind.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.nio.file.Paths;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jdesktop.swingx.JXList;

import pind.methods.Methods;

public class gui extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2579902883545746312L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui frame = new gui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public gui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		final JFileChooser jf=new JFileChooser();	
		jf.setFileFilter(new FileNameExtensionFilter("textual files", "txt", "csv","log"));
		jf.setFileSelectionMode(JFileChooser.FILES_ONLY);
		JMenu mnOpenLineSeparated = new JMenu("Open line separated text");
		mnFile.add(mnOpenLineSeparated);
		
		JMenu mnOpenSpaceSeparaded = new JMenu("Open space separated text");
		mnFile.add(mnOpenSpaceSeparaded);
		
		JMenu mnSaveLineSeparated = new JMenu("Save line separated");
		mnFile.add(mnSaveLineSeparated);
		
		JMenu mnSaveSpaceSeparated = new JMenu("Save space separated");
		mnFile.add(mnSaveSpaceSeparated);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		final JXList list = new JXList();
		
		scrollPane.setViewportView(list);
		mnOpenLineSeparated.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(jf.showOpenDialog(gui.this)==JFileChooser.APPROVE_OPTION) {
					try {
						Methods.getInstance().loadLineSep(Paths.get(jf.getSelectedFile().toURI()));
						DefaultListModel<String> model = new DefaultListModel<String>();
						for (String element : Methods.getInstance().getList()) {
							model.addElement(element);
							System.out.println(element);
						}
						list.setModel(model);
					} catch (IOException e) {
						JOptionPane.showMessageDialog(gui.this, "File open failed"+e.getMessage(),"Load error",JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
				}
				
			}
		});
		mnOpenSpaceSeparaded.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(jf.showOpenDialog(gui.this)==JFileChooser.APPROVE_OPTION) {
					try {
						Methods.getInstance().loadSpaceSep(Paths.get(jf.getSelectedFile().toURI()));
						DefaultListModel<String> model = new DefaultListModel<String>();
						for (String element : Methods.getInstance().getList()) {
							model.addElement(element);
							System.out.println(element);
						}
						list.setModel(model);
					} catch (IOException e) {
						JOptionPane.showMessageDialog(gui.this, "File open failed"+e.getMessage(),"Load error",JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
				}
				
			}
		});
		mnSaveLineSeparated.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(jf.showSaveDialog(gui.this)==JFileChooser.APPROVE_OPTION) {
					try {
						Methods.getInstance().saveLineSep(Paths.get(jf.getSelectedFile().toURI()));
					} catch (IOException e) {
						JOptionPane.showMessageDialog(gui.this, "File save failed"+e.getMessage(),"Save error",JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
				}
			}
		});
		mnSaveSpaceSeparated.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(jf.showSaveDialog(gui.this)==JFileChooser.APPROVE_OPTION) {
					try {
						Methods.getInstance().saveSpaceSep(Paths.get(jf.getSelectedFile().toURI()));
					} catch (IOException e) {
						JOptionPane.showMessageDialog(gui.this, "File save failed"+e.getMessage(),"Save error",JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
				}
			}
		});
	}
}
