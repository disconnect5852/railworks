-- MySQL dump 10.13  Distrib 5.7.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ulytestdb
-- ------------------------------------------------------
-- Server version	5.7.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AMOUNT` float DEFAULT NULL,
  `APPROVED` tinyint(1) DEFAULT '0',
  `APPLICANT_USERNAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Applications_APPLICANT_USERNAME` (`APPLICANT_USERNAME`),
  CONSTRAINT `FK_Applications_APPLICANT_USERNAME` FOREIGN KEY (`APPLICANT_USERNAME`) REFERENCES `xuser` (`USERNAME`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,54645,0,'godrulz'),(2,876868,0,'godrulz'),(3,754463,0,'godrulz'),(4,45345.4,0,'godrulz'),(5,6556.7,0,'godrulz'),(6,666,0,'godrulz'),(7,54454.8,0,'gyoker'),(8,649,1,'juzer'),(9,645553,1,'juzer'),(10,6566.63,1,'usd'),(11,76764400,0,'juzer'),(12,76455,0,'gyoker'),(13,76323,0,'juzer'),(14,8967670,1,'pofazoli');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `DATE` datetime NOT NULL,
  `EVENT` varchar(255) DEFAULT NULL,
  `SUCCESS` tinyint(1) DEFAULT '0',
  `USERNAME_USERNAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DATE`),
  KEY `FK_Events_USERNAME_USERNAME` (`USERNAME_USERNAME`),
  CONSTRAINT `FK_Events_USERNAME_USERNAME` FOREIGN KEY (`USERNAME_USERNAME`) REFERENCES `xuser` (`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES ('2017-11-28 15:29:22','Add user',1,'godrulz'),('2017-11-28 15:38:16','Add user',1,'godrulz'),('2017-11-28 17:10:33','Add application',1,'godrulz'),('2017-11-28 17:40:15','Add application',1,'godrulz'),('2017-11-28 18:11:37','Add application',1,'godrulz'),('2017-11-28 18:23:22','Add user',1,'godrulz'),('2017-11-28 18:25:04','Add application',1,'godrulz'),('2017-11-28 18:25:20','Add application',1,'godrulz'),('2017-11-28 18:36:45','Modify application',1,'godrulz'),('2017-11-28 18:37:13','Modify application',1,'godrulz'),('2017-11-28 18:38:43','Modify application',1,'godrulz'),('2017-11-28 23:03:13','Add user',1,'godrulz'),('2017-11-29 11:47:11','Application amount modify',1,'gyoker'),('2017-11-29 11:47:43','Add application',1,'gyoker'),('2017-11-29 11:48:17','Application amount modify',1,'gyoker'),('2017-11-29 11:59:29','Add user',1,'godrulz'),('2017-11-29 12:09:01','Add application',1,'juzer'),('2017-11-29 12:09:10','Add application',1,'juzer'),('2017-11-29 12:09:15','Application amount modify',1,'juzer'),('2017-11-29 12:21:57','Add application',1,'usd'),('2017-11-29 12:22:36','Add application',1,'juzer'),('2017-12-02 23:33:53','Application amount modify',1,'gyoker'),('2017-12-03 12:14:42','Add application',1,'gyoker'),('2017-12-03 12:15:24','Add application',1,'juzer'),('2017-12-03 12:15:43','Application amount modify',1,'juzer'),('2017-12-03 12:15:45','Application amount modify',1,'juzer'),('2017-12-03 12:15:55','Application amount modify',1,'juzer'),('2017-12-03 12:40:18','Add user',1,'godrulz'),('2017-12-03 12:41:43','Add application',1,'pofazoli'),('2017-12-03 12:41:52','Application amount modify',1,'pofazoli'),('2017-12-03 12:43:00','Application amount modify',1,'gyoker'),('2017-12-03 13:37:35','Application amount modify',1,'gyoker'),('2017-12-03 20:34:31','Add user',1,'godrulz'),('2017-12-03 20:44:08','Add user',1,'godrulz');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequence`
--

DROP TABLE IF EXISTS `sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequence` (
  `SEQ_NAME` varchar(50) NOT NULL,
  `SEQ_COUNT` decimal(38,0) DEFAULT NULL,
  PRIMARY KEY (`SEQ_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequence`
--

LOCK TABLES `sequence` WRITE;
/*!40000 ALTER TABLE `sequence` DISABLE KEYS */;
INSERT INTO `sequence` VALUES ('SEQ_GEN',0);
/*!40000 ALTER TABLE `sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xuser`
--

DROP TABLE IF EXISTS `xuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xuser` (
  `USERNAME` varchar(255) NOT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT NULL,
  PRIMARY KEY (`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xuser`
--

LOCK TABLES `xuser` WRITE;
/*!40000 ALTER TABLE `xuser` DISABLE KEYS */;
INSERT INTO `xuser` VALUES ('','','',2),('645645fdgdf','fd43346dsg','434634sdfgsd',0),('asdasdasd','ffdsf','sdfdsfs',0),('dfhdh','hdfh','ewfwef',0),('fdfgdh','fdhdfhdf','hdfhdfh',0),('fgf','gfgdfgdf','fdgdfgfd',0),('fgsdf','sdfsdf','dsfsdf',0),('ghfdsgsd','ewtwet','wrqwrqw',0),('ghfg','hfghfgh','gfhfgh',0),('godrulz','GOD','impossible',2),('gyoker','Gyömbér Gyöngyvér','jelszo',1),('hfghfg','fghfgh','fghfghfgh',0),('hgfhfg','fhgfhfgh','fghfghg',0),('hgh','hfgh','hfghf',0),('hghfgh','fghfghfg','gfhfghfgh',0),('juzer','You Zher Ping','12345',0),('kismajom','zakkant','korte',0),('pofazoli','Pofá Zoltán','neszojjabe',0),('sfsdf','sfsdfs','fsdf',0),('ujadmin','Jsf is so 2004, in 2017','lol',2),('usd','asgsdgwetwet','643636',0),('zezerzerz','dfhh','hfg',0);
/*!40000 ALTER TABLE `xuser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-03 21:00:41
