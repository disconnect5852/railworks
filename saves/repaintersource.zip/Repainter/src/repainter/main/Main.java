package repainter.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import repainter.data.DataRow;

public class Main {
	private static List<DataRow> rows= new ArrayList<DataRow>();
	public static void readrows (String doc) throws Exception {
		//Files.newInputStream(doc, StandardOpenOption.READ).
		BufferedReader reader= new BufferedReader(new FileReader(doc));
		rows.clear();
		String rawline;
		while ((rawline = reader.readLine()) != null) {
			String[] line= rawline.split(";");
			Path[] arr= new Path[line.length-4];
			int j=0;
			for (int i=4; i<line.length; i++) {
				arr[j]= Paths.get(line[i]);
				j++;
			}
			DataRow row=new DataRow(Paths.get(line[0]), Paths.get(line[1]), line[2], line[3], arr);
			System.out.println(row);
			rows.add(row);
		}
		reader.close();
}
	public static void main(String[] args) {
		try {
			readrows(args[0]);
			for (DataRow row : rows) {
				row.applyScriptRow();
			}
		} catch (Exception e) {
			System.out.println("Badly formed script file?");
			e.printStackTrace();
		}

	}

}
