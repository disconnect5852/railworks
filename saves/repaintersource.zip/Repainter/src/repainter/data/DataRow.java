package repainter.data;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DataRow {
	private Path sourceBp,sourcemodel;
	private String dirName,ingameName;
	private Path[] repaintTx;
	private static final String SERZCMD="serz.exe \"";
	private static final String SERZCMD_CLOSE="\"";
	private static final String FILE_SEPARATOR="\\";
	
	public DataRow(Path sourceBp, Path sourcemodel, String dirName,
			String ingameName, Path[] repaintTx) {
		super();
		this.sourceBp = sourceBp;
		this.sourcemodel = sourcemodel;
		this.dirName = dirName;
		this.ingameName = ingameName;
		this.repaintTx = repaintTx;
	}
	//not used
	/*public Path getSourceBp() {
		return sourceBp;
	}
	public void setSourceBp(Path sourceBp) {
		this.sourceBp = sourceBp;
	}
	public Path getSourcemodel() {
		return sourcemodel;
	}
	public void setSourcemodel(Path sourcemodel) {
		this.sourcemodel = sourcemodel;
	}
	public Path[] getRepaintTx() {
		return repaintTx;
	}
	public void setRepaintTx(Path[] repaintTx) {
		this.repaintTx = repaintTx;
	}
	public String getDirName() {
		return dirName;
	}
	public void setDirName(String dirName) {
		this.dirName = dirName;
	}
	public String getIngameName() {
		return ingameName;
	}
	public void setIngameName(String ingameName) {
		this.ingameName = ingameName;
	}*/
	
	public void applyScriptRow () throws Exception {
		boolean isBin=false;
		//Detect if the file is bin and decompress it with serz
		if (sourceBp.toString().endsWith(".bin")) {
			System.out.println("BIN");
			isBin=true;
			Runtime.getRuntime().exec(SERZCMD+sourceBp.toAbsolutePath()+SERZCMD_CLOSE).waitFor();
			sourceBp= Paths.get(sourceBp.toString().replaceFirst(".bin",".xml"));
		}
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder= factory.newDocumentBuilder();
		Document doc= builder.parse(sourceBp.toFile());
		//Get the Ingame name nodes
		NodeList nameNodes = (NodeList) XPathFactory.newInstance().newXPath().evaluate("//English | //French | //Italian | //German | //Polish | //Spanish | //Dutch | //Russian", doc, XPathConstants.NODESET);
		for (int i=0; i<nameNodes.getLength(); i++) {
			//And change them to the specified
			nameNodes.item(i).setTextContent(ingameName);
		}
		//Get the geometry path node...
		NodeList geoNodes = (NodeList) XPathFactory.newInstance().newXPath().evaluate("//GeometryID", doc, XPathConstants.NODESET);
		Node node= geoNodes.item(0);
		Path xmlroot=Paths.get(Paths.get(node.getTextContent()).getParent().getParent()+FILE_SEPARATOR+dirName);
		Path root=Paths.get("Assets\\"+xmlroot);
		Path pth=Paths.get( xmlroot+"\\[00]"+stripExtension(sourcemodel.getFileName().toString()));
		//...and relink it to the new repaint folder
		node.setTextContent(pth.toString());
		//null the path for the autonumbering CSV as the number is probably "burned" into the texture.
		Node csvNode = (Node) XPathFactory.newInstance().newXPath().evaluate("//CsvFile", doc, XPathConstants.NODE);
		csvNode.setTextContent("");
		//Set the internal names (it seems these aren't used by the game, but the devil never sleeps...)
		NodeList internalNameNodes = (NodeList) XPathFactory.newInstance().newXPath().evaluate("//Name | //EngineName", doc, XPathConstants.NODESET);
		for (int i=0; i<internalNameNodes.getLength(); i++) {
			Node thenode= internalNameNodes.item(i);
			if (!(thenode.getParentNode().getNodeName().equals("cScriptComponentBlueprint"))) {
				thenode.setTextContent(dirName);
			}
		}
		
		toXML(doc,isBin, root);
		
			
	}
    private static String stripExtension (String str) {
        // Handle null case specially.
        if (str == null) return null;
        // Get position of last '.'.
        int pos = str.lastIndexOf(".");
        // If there wasn't any '.' just return the string as is.
        if (pos == -1) return str;
        // Otherwise return the string, up to the dot.
        return str.substring(0, pos);
    }
	
	private void toXML(Document doc, boolean isBin, Path root) throws Exception
	{
		TransformerFactory xf = TransformerFactory.newInstance();
		xf.setAttribute("indent-number", new Integer(2));

		Transformer xformer = xf.newTransformer();
		xformer.setOutputProperty(OutputKeys.METHOD, "xml");
		xformer.setOutputProperty(OutputKeys.INDENT, "yes");
		xformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		//xformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");
		Path outputfile=Paths.get(root.toAbsolutePath()+FILE_SEPARATOR+dirName+".xml");
		System.out.println(outputfile);
		Files.createDirectories(root);
		OutputStream os=Files.newOutputStream(outputfile, StandardOpenOption.CREATE);
		StreamResult out = new StreamResult(new StringWriter());
		//new OutputStreamWriter(os,"UTF-8")
		//FIX for serz, as it doesn't accept NULL(void) xml nodes, so a whitespace should be included there
		NodeList nodes= (NodeList) XPathFactory.newInstance().newXPath().evaluate("//*[@type='cDeltaString']", doc, XPathConstants.NODESET);
		for (int i=0; i<nodes.getLength(); i++) {
			Node currnode=  nodes.item(i);
			if (currnode.getTextContent()=="") {
				currnode.setTextContent(" ");
			}
			//currnode.appendChild(doc.createTextNode("&#x200B;"));
		}
		//END of fix for serz
		xformer.transform(new DOMSource(doc), out);
		//String fin= out.getWriter().toString().replaceAll("<(\\w+)( [^/>]*)?/>", "<$1$2></$1>");
		//ANOTHER fix for the game, as it also don't accept spaces at textcontent...
		String fin= out.getWriter().toString().replaceAll("> <", "><");
		//System.out.println(fin);
		BufferedOutputStream bw= new BufferedOutputStream(os);
		bw.write(fin.getBytes("UTF-8"));
		os.close();
		if (isBin) {
			//recompress the xml to bin if it was bin
			Runtime.getRuntime().exec(SERZCMD+outputfile+SERZCMD_CLOSE);
		}
		//copy the source model to the new repaint folder
		Files.copy(sourcemodel, Paths.get(root.toString()+/*"\\"+dirName+*/FILE_SEPARATOR+sourcemodel.getFileName()), StandardCopyOption.REPLACE_EXISTING);
		for (Path path : repaintTx) {
			//copy the new repaint texture(s) to the new repaint folder
			Files.copy(path, Paths.get(root.toString()+/*"\\"+dirName+*/FILE_SEPARATOR+path.getFileName()), StandardCopyOption.REPLACE_EXISTING);
		}

	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ScriptRow [SourceBlueprint=").append(sourceBp)
				.append(", Sourcemodel=").append(sourcemodel)
				.append(", New repaint folder name=").append(dirName).append(", Ingame Name=")
				.append(ingameName).append(", Repaint Texture(s)=");
				for (Path elem : repaintTx) {
					builder.append(elem);
					builder.append("; ");
				} 
				builder.append("]");
				builder.append(System.getProperty("line.separator"));
		return builder.toString();
	}
}
