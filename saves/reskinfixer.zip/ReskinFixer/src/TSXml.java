import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class TSXml extends Thread {
	private static final String PROVIDERSTR = "Provider";
	private static final String PRODUCTSTR = "Product";
	private static final String BLUEPRINTIDSTR = "BlueprintID";
	private static final String FILESEP=System.getProperty("file.separator");
	private static final XPath XPATH=XPathFactory.newInstance().newXPath();
	private static Path serzPath;
	private Path filePath;
	private final boolean isBin;
	private static final char QUOTE='"';
	private static final char SPACE=' ';

	public TSXml(Path filePath) {
		super();
		this.filePath = filePath.toAbsolutePath();
		String fpth=filePath.toString();
		if (".bin".equalsIgnoreCase(fpth.substring(fpth.lastIndexOf(".")))) {
			isBin=true;
		} else{
			isBin=true;
		}
		System.out.println(isBin);
	}
	
	public static void setSerzPath(Path serzPath) {
		TSXml.serzPath = serzPath.toAbsolutePath();
	}
	

	@Override
	public void run() {
		try {
		if (isBin) {
			serzIt(filePath);
			Files.copy(filePath,Paths.get(filePath.toString()+".bak"), StandardCopyOption.REPLACE_EXISTING);
			Files.deleteIfExists(Paths.get(filePath.toString()+".md5"));
			String filephstr= filePath.toString();
			filePath= Paths.get(filephstr.substring(0, filephstr.lastIndexOf(".")+1)+"xml");
		}
			Document doc;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder= factory.newDocumentBuilder();
			doc= builder.parse(Files.newInputStream(filePath, StandardOpenOption.READ));
			NodeList nodes = (NodeList) XPATH.evaluate("//cOwnedEntity", doc, XPathConstants.NODESET);
			for (int i=0; i<nodes.getLength(); i++ ) {
				Node mainnode=nodes.item(i);
				
				Node[] mainbp= getAbsoluteRef(getFirstSubElementByName(mainnode, "BlueprintID"));
				//Node firstsub= getFirstSubElement();
				//System.out.println(blueprintAbslib.getNodeName());
				//Node firstsub= getFirstSubElement(blueprintAbslib);
				//System.out.println(firstsub.getNodeName());
				//Node blueprintID = getFirstSubElementByName(firstsub,BLUEPRINTIDSTR);
				Path bppath=makeFullPath(mainbp[0].getTextContent(),mainbp[1].getTextContent(),mainbp[2].getTextContent());
				if (isReskin(bppath)) {
					Node[] reskinbp= getAbsoluteRef(getFirstSubElementByName(mainnode, "ReskinBlueprintID"));
					for (int j=0; j<3; j++) {
						reskinbp[j].setTextContent(mainbp[j].getTextContent());
					}
					serzIt(bppath);
					String bppthstr=bppath.toString();
					Document reskbp= builder.parse(Files.newInputStream(Paths.get(bppthstr.substring(0, bppthstr.toString().lastIndexOf(".")+1)+"xml"), StandardOpenOption.READ));
					NodeList sourcebp = (NodeList) XPATH.evaluate("//Provider | //Product | //BlueprintID", reskbp, XPathConstants.NODESET);
					for (int j=0; j<3; j++) {
						mainbp[j].setTextContent(sourcebp.item(j).getTextContent());
					}

				/*System.out.println(isReskin(mainbp[0].getTextContent(),mainbp[1].getTextContent(),mainbp[2].getTextContent()));
				System.out.println(mainbp[0].getTextContent());
				System.out.println(mainbp[1].getTextContent());
				System.out.println(mainbp[2].getTextContent());
				System.out.println(isReskin(reskinbp[0].getTextContent(),reskinbp[1].getTextContent(),reskinbp[2].getTextContent()));
				System.out.println(reskinbp[0].getTextContent());
				System.out.println(reskinbp[1].getTextContent());
				System.out.println(reskinbp[2].getTextContent()+"\n");*/
				//Node libroot= getFirstSubElement(getFirstSubElement(firstsub));
				//Node provider=getFirstSubElementByName(libroot,PROVIDERSTR);
				//Node product=getFirstSubElementByName(libroot,PRODUCTSTR);
				//Node blueprintlib=getFirstSubElement(getFirstSubElement(blueprintAbslib));
				TransformerFactory xf = TransformerFactory.newInstance();
				xf.setAttribute("indent-number", new Integer(2));

				Transformer xformer = xf.newTransformer();
				xformer.setOutputProperty(OutputKeys.METHOD, "xml");
				xformer.setOutputProperty(OutputKeys.INDENT, "yes");
				xformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

				StringWriter strwr= new StringWriter();
				Result out = new StreamResult(strwr /*new OutputStreamWriter(fos,"UTF-8")*/);
				stupidKUJU(doc);
				xformer.transform(new DOMSource(doc), out);
				BufferedWriter bwr = new BufferedWriter(Files.newBufferedWriter(filePath, Charset.forName("UTF-8"), StandardOpenOption.WRITE) /*new FileWriter(file)*/);
				bwr.write(strwr.toString().replaceAll("> <", "><"));
				bwr.close();
				serzIt(filePath);
				Files.deleteIfExists(filePath);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		
	}
	private static void serzIt(Path toserzed) {
		//System.out.println("serzit");
		StringBuilder sb = new StringBuilder();
		sb.append(serzPath);
		sb.append(SPACE);
		sb.append(QUOTE);
		sb.append(toserzed.toAbsolutePath());
		sb.append(QUOTE);
		try {
			Runtime.getRuntime().exec(sb.toString()).waitFor();
		} catch (InterruptedException | IOException e) {
			e.printStackTrace();
			return;
		}
	}
	private static Path makeFullPath(String provider, String product, String blueprintID) {
		if (!(isEmptyOrBlank(blueprintID) ||isEmptyOrBlank(provider)||isEmptyOrBlank(product))) {
			StringBuilder strb= new StringBuilder(serzPath.getParent().toString());
			strb.append(FILESEP);
			strb.append("Assets");
			strb.append(FILESEP);
			strb.append(provider);
			strb.append(FILESEP);
			strb.append(product);
			strb.append(FILESEP);
			strb.append(blueprintID.substring(0, blueprintID.lastIndexOf(".")+1)+"bin");
			return Paths.get(strb.toString());
		}
		return null;
	}
	private static boolean isReskin(Path file) throws IOException {
		final Scanner fileScanner = new Scanner(file.toFile());
		final Pattern pattern =  Pattern.compile("cReskinBlueprint");
		//Matcher matcher = null; 
		while(fileScanner.hasNextLine()){ 
			String line = fileScanner.nextLine();  
			Matcher matcher = pattern.matcher(line);
			if(matcher.find()){
				fileScanner.close();
				System.out.println("Reskin: "+file);
				return true; 
			}

		}
		fileScanner.close();
		System.out.println("Not reskin: "+file);
		return false;
	}
		
	
	public static boolean isEmptyOrBlank(String str) {
		return str == null || str.trim().isEmpty();
	}
	private Node[] getAbsoluteRef(Node startnode) {
		Node[] output= new Node[3];
		Node firstsub= getFirstSubElement(startnode);
		output[2] = getFirstSubElementByName(firstsub,BLUEPRINTIDSTR);
		Node libroot= getFirstSubElement(getFirstSubElement(firstsub));
		output[0]=getFirstSubElementByName(libroot,PROVIDERSTR);
		output[1]=getFirstSubElementByName(libroot,PRODUCTSTR);
		return output;
	}
	private Node getFirstSubElementByName(Node node,String name) {
		if (node!=null) {
			NodeList children= node.getChildNodes();
			if (children!=null) {
				for (int i=0; i<children.getLength(); i++) {
					Node child= children.item(i);
					if (child.getNodeType()==Node.ELEMENT_NODE && child.getNodeName().equals(name)) {
						return child;
					}
				}
			}
		}
		return null;
	}
	private Node getFirstSubElement(Node node) {
		if (node!=null) {
			NodeList children= node.getChildNodes();
			if (children!=null) {
				for (int i=0; i<children.getLength(); i++) {
					Node child= children.item(i);
					if (child.getNodeType()==Node.ELEMENT_NODE) {
						return child;
					}
				}
			}
		}
		return null;
	}
	private void stupidKUJU(Document docu) throws Exception  { // put whitespace to empty nodes, because serz.exe crashes with xml that contain void tags.
		NodeList nodes= (NodeList) XPATH.evaluate("//*[@type='cDeltaString']", docu, XPathConstants.NODESET);
		//System.out.println(nodes.getLength());
		for (int i=0; i<nodes.getLength(); i++) {
			Node currnode=  nodes.item(i);
			if (currnode.getTextContent()=="") {
				currnode.setTextContent(" ");
			}
		}
	}
	public static void main(String[] args) {
		/*TSXml.setSerzPath(Paths.get("f:\\Steam\\steamapps\\common\\railworks\\serz.exe"));
		TSXml xml= new TSXml(Paths.get("e:\\teszt\\cbef2db6-4492-4c3a-bf34-5567e12d46bf\\Scenario.bin"));
		xml.start();*/
		try {
			System.out.println(WinRegistry.readString(WinRegistry.HKEY_LOCAL_MACHINE, "SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App 24010", "UninstallString"));
		} catch (IllegalArgumentException | IllegalAccessException
				| InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
