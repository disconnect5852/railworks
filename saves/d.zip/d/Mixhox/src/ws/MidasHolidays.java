package ws;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.naming.NamingException;

import classes.BooleanResponse;
import classes.DateResponse;
import classes.Holiday;
import classes.MidasHolidaysCacheDaemon;
import classes.QueryParam;
import classes.HolidayResponse.Fault;
import exeption.NullInputExeption;
import exeption.NullResultExeption;

@WebService(name = "MidasHolidays", targetNamespace = "http://ws.volksbank.hu/midas/holidays", serviceName = "MidasHolidaysService", portName = "MidasHolidaysPort")
public class MidasHolidays {
	private static final String DAYCOLUMN_CONST = "DG";
	private static final Map<Integer, String> MONTHMAP = initializeMap();
	private static final String EMPTY_STRING = "";
	private static final String RESULT_NULL_EXEPTION = "ResultSet is NULL, check parameters! ";
	private static final String INPUT_NULL_EXEPTION = "Input is NULL ";
	private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
	public static final String NOLOCATION_FLAG="***";
	private static MidasHolidaysCacheDaemon DAEMON = null;
	private static Map<QueryParam, Map<String, Boolean>> CACHE;

	public MidasHolidays() throws NamingException {
		DAEMON = MidasHolidaysCacheDaemon.getInstance();
		CACHE = DAEMON.getCache();
	}

	private static final HashMap<Integer, String> initializeMap() {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(0, "JA");
		map.put(1, "FE");
		map.put(2, "MA");
		map.put(3, "AP");
		map.put(4, "MY");
		map.put(5, "JU");
		map.put(6, "JL");
		map.put(7, "AU");
		map.put(8, "SE");
		map.put(9, "OC");
		map.put(10, "NO");
		map.put(11, "DE");
		return map;
	}

	private void checkNullHoliday(Holiday holiday) throws NullInputExeption {
		if (holiday == null || holiday.getCurrency() == null
				|| holiday.getCurrency().equals(EMPTY_STRING)
				|| holiday.getDate() == null
				|| holiday.getDate().equals(EMPTY_STRING)) {
			throw new NullInputExeption();
		}
	}

	@WebMethod
	public BooleanResponse isHoliday(Holiday holiday) {
		Calendar cal = Calendar.getInstance();
		SDF.setCalendar(cal);
		boolean retr;
		try {
			checkNullHoliday(holiday);
			cal.setTime(SDF.parse(holiday.getDate()));
			QueryParam queryparam = new QueryParam(holiday.getCurrency(),
					holiday.getLocation(), cal.get(Calendar.YEAR),0);
			System.out.println("inputqueryparam"+queryparam.getCurrency()+queryparam.getLocation()+queryparam.getYear());
			retr = parseResult(doQuery(queryparam), cal.get(Calendar.MONTH),
					cal.get(Calendar.DAY_OF_MONTH));
			// stmt.close();
			return new BooleanResponse(Fault.success, retr);
		} catch (ParseException e) {
			// e.printStackTrace();
			return new BooleanResponse(Fault.invalidDate, null);
		} catch (NullResultExeption e) {
			// e.printStackTrace();
			return new BooleanResponse(Fault.notFound, null);
		} catch (NullInputExeption e) {
			// e.printStackTrace();
			return new BooleanResponse(Fault.requiredParameterNull, null);
		} /*
		 * finally { if (!(conn==null) && !conn.isClosed()) { conn.close(); } }
		 */

	}

	private static final String toDoubleDigit(int i) {
		if (i < 10) {
			return "0" + Integer.toString(i);
		}
		return Integer.toString(i);
	}

	private Map<String, Boolean> doQuery(QueryParam query)
			throws NullResultExeption {
		// System.out.println("queryparam"+query.getCurrency()+query.getLocation()+query.getYear());
		// System.out.println("contains "+CACHE.containsKey(query));
		System.out.println(CACHE.size());
		if (CACHE.containsKey(query)) {
			// System.out.println("REadcache");
			return CACHE.get(query);
		}
		throw new NullResultExeption(RESULT_NULL_EXEPTION);

	}

	private boolean parseResult(Map<String, Boolean> result, int month,
			int dayOfMonth) {
		return result.get(DAYCOLUMN_CONST + MONTHMAP.get(month)
				+ toDoubleDigit(dayOfMonth));
		// System.out.println("colum: "+columnname);

	}

	@WebMethod
	public BooleanResponse[] areHolidays(Holiday[] holidays)
			throws SQLException {
		if (holidays == null || holidays.length == 0) {
			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
		}

		List<BooleanResponse> resultlist = new ArrayList<BooleanResponse>();
		for (Holiday holiday : holidays) {
			try {
				checkNullHoliday(holiday);
				Calendar cal = Calendar.getInstance();
				SDF.setCalendar(cal);
				cal.setTime(SDF.parse(holiday.getDate()));
				QueryParam queryparam = new QueryParam(holiday.getCurrency(),
						holiday.getLocation(), cal.get(Calendar.YEAR),0);
				resultlist.add(new BooleanResponse(Fault.success, parseResult(
						doQuery(queryparam), cal.get(Calendar.MONTH), cal
								.get(Calendar.DAY_OF_MONTH))));
			} catch (ParseException e) {
				// e.printStackTrace();
				resultlist.add(new BooleanResponse(Fault.invalidDate, null));

			} catch (NullResultExeption e) {
				// e.printStackTrace();
				resultlist.add(new BooleanResponse(Fault.notFound, null));
			} catch (NullInputExeption e) {
				// e.printStackTrace();
				resultlist.add(new BooleanResponse(Fault.requiredParameterNull,
						null));
			}

		}
		return resultlist.toArray(new BooleanResponse[resultlist.size()]);
	}

	private DateResponse getNonHoliday(Holiday holiday, boolean next) {
		Calendar cal = Calendar.getInstance();
		SDF.setCalendar(cal);
		try {
			checkNullHoliday(holiday);
			cal.setTime(SDF.parse(holiday.getDate()));
			QueryParam queryparam = new QueryParam(holiday.getCurrency(),
					holiday.getLocation(), cal.get(Calendar.YEAR),0);
			Map<String, Boolean> rs = doQuery(queryparam);
			boolean result = parseResult(rs, cal.get(Calendar.MONTH), cal
					.get(Calendar.DAY_OF_MONTH));
			int year = cal.get(Calendar.YEAR);

			while (result) {
				cal.add(Calendar.DAY_OF_YEAR, next ? 1 : -1);
				if (!(cal.get(Calendar.YEAR) == year)) {
					queryparam = new QueryParam(holiday.getCurrency(), holiday
							.getLocation(), cal.get(Calendar.YEAR),0);
					rs = doQuery(queryparam);
					year = cal.get(Calendar.YEAR);
				}
				result = parseResult(rs, cal.get(Calendar.MONTH), cal
						.get(Calendar.DAY_OF_MONTH));
			}
		} catch (NullInputExeption e) {
			// e.printStackTrace();
			return new DateResponse(Fault.requiredParameterNull, null);

		} catch (ParseException e) {
			// e.printStackTrace();
			return new DateResponse(Fault.invalidDate, null);
		} catch (NullResultExeption e) {
			// e.printStackTrace();
			return new DateResponse(Fault.notFound, null);
		}
		return new DateResponse(Fault.success, cal.getTime());
	}

	@WebMethod
	public DateResponse getNextNonHoliday(Holiday holiday) {

		return getNonHoliday(holiday, true);
	}

	@WebMethod()
	public DateResponse getPrevNonHoliday(Holiday holiday) {
		return getNonHoliday(holiday, false);
	}

	@WebMethod
	public DateResponse[] getNextNNonHoliday(Holiday[] holidays)
			throws Exception {
		if (holidays == null || holidays.length == 0) {
			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
		}
		List<DateResponse> result = new ArrayList<DateResponse>();
		for (Holiday holiday : holidays) {
			result.add(getNonHoliday(holiday, true));
		}
		return result.toArray(new DateResponse[result.size()]);
	}

	@WebMethod
	public DateResponse[] getPrevNNonHoliday(Holiday[] holidays)
			throws Exception {
		if (holidays == null || holidays.length == 0) {
			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
		}
		List<DateResponse> result = new ArrayList<DateResponse>();
		for (Holiday holiday : holidays) {
			result.add(getNonHoliday(holiday, false));
		}
		return result.toArray(new DateResponse[result.size()]);
	}
	/*public static void main(String[] args) {
		MidasHolidays mh=null;
		try {
			mh = new MidasHolidays();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BooleanResponse resp= mh.isHoliday(new Holiday("CAD",null,"2000-01-04"));
		System.out.println("Status: "+resp.getStatus()+"eredmeny: "+ resp.isResponse() );
		
		
	}*/
}

