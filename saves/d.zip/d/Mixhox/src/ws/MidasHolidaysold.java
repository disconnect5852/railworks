//package ws;
//
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.jws.WebMethod;
//import javax.jws.WebService;
//import javax.naming.Context;
//import javax.naming.InitialContext;
//import javax.naming.NamingException;
//import javax.sql.DataSource;
//
//import classes.BooleanResponse;
//import classes.DateResponse;
//import classes.Holiday;
//import classes.MidasHolidaysCacheDaemon;
//import classes.QueryParam;
//import classes.HolidayResponse.Fault;
//import exeption.NullInputExeption;
//import exeption.NullResultExeption;
//@WebService(name="MidasHolidays", targetNamespace="http://ws.volksbank.hu/midas/holidays", serviceName="MidasHolidaysService", portName="MidasHolidaysPort")
//public class MidasHolidaysold {
//	private static final String DAYCOLUMN_CONST="DG";
//	private static final char TRUE_FLAG='X';
//	private static final String NOLOC_FLAG="***"; //
//	//private static final String SQL_QUERY_ISHOLIDAY="SELECT * FROM SDHOLPD WHERE DGCYCD=? AND DGLCCD=? AND DGYRNB=?";
//	private static final String SQL_QUERY_ISHOLIDAY="SELECT * FROM V8DMLIB.SDHOLPD WHERE DGCYCD=? AND DGLCCD=? AND DGYRNB=?";
//	//private static final ResourceBundle PROPERTIES=ResourceBundle.getBundle("resources.jdbc");
//	private static final Map<Integer,String> MONTHMAP=initializeMap();
//	private static final String EMPTY_STRING="";
//	private static final String RESULT_NULL_EXEPTION="ResultSet is NULL, check parameters! ";
//	private static final String INPUT_NULL_EXEPTION="Input is NULL ";
//	private static final SimpleDateFormat SDF=new SimpleDateFormat("yyyy-MM-dd");
//	private static int counter=0;
//	private static Map<QueryParam, Map<String,Boolean>> CACHE=new HashMap<QueryParam, Map<String,Boolean>>();
//	//private static final SimpleTimeZone STZ= new SimpleTimeZone(SimpleTimeZone.STANDARD_TIME,"GMT");
//	private static DataSource DATASOURCE=null;
//	private static final String FIRSTDAYCOLUMNAME="DGJA01";
//	//private static final int  TOTAL_DAYS_IN_DB=371;
//	
//	
//	
//	/*public MidasHolidays() throws NamingException {
//		Context ctx= new InitialContext();
//		DATASOURCE=(DataSource)ctx.lookup("jdbc/midasv8");
//	}*/
//	private static final HashMap<Integer,String> initializeMap() {
//		HashMap<Integer,String> map = new HashMap<Integer,String>();
//		map.put(0, "JA");
//		map.put(1, "FE");
//		map.put(2, "MA");
//		map.put(3, "AP");
//		map.put(4, "MY");
//		map.put(5, "JU");
//		map.put(6, "JL");
//		map.put(7, "AU");
//		map.put(8, "SE");
//		map.put(9, "OC");
//		map.put(10, "NO");
//		map.put(11, "DE");
//		return map;
//	}
//	
//	/*private final Connection getDBConnect() throws ClassNotFoundException, SQLException{
//		Connection conn=null;
//				System.out.println("Params"+PROPERTIES.getString("driverClass")+" "+PROPERTIES.getString("connectionURL"));
//				Class.forName(PROPERTIES.getString("driverClass"));
//				conn=DriverManager.getConnection(PROPERTIES.getString("connectionURL"),PROPERTIES.getString("username"),PROPERTIES.getString("password"));
//		return conn;
//	}*/
//	
//	//private static final Connection getDBConnect() throws NamingException, SQLException {
//			/*Context ctx= new InitialContext();
//			DataSource ds= (DataSource)ctx.lookup("jdbc/midasv8");*/
//			//System.out.println("CONNECT");
//		//return DATASOURCE.getConnection();
//	//}
//	
//	private void checkNullHoliday(Holiday holiday) throws NullInputExeption {
//		if (holiday==null || holiday.getCurrency()==null || holiday.getCurrency().equals(EMPTY_STRING) || holiday.getDate()==null || holiday.getDate().equals(EMPTY_STRING) ) {
//			 throw new NullInputExeption();
//		}
//	}
//	
//	@WebMethod
//    public BooleanResponse isHoliday(Holiday holiday) throws Exception {
//    		Connection conn=null;
//    		PreparedStatement stmt=null;
//    		Calendar cal= Calendar.getInstance();
//    		SDF.setCalendar(cal);
//			boolean retr;
//			try {
//				checkNullHoliday(holiday);
//				cal.setTime(SDF.parse(holiday.getDate()));
//				conn= getDBConnect();
//				stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//				QueryParam queryparam= new QueryParam(holiday.getCurrency(),holiday.getLocation(),cal.get(Calendar.YEAR));
//				retr = parseResult(doQuery(stmt, queryparam), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
//				//stmt.close();
//				return new BooleanResponse(Fault.success,retr);
//			} catch (ParseException e) {
//				//e.printStackTrace();
//				return new BooleanResponse(Fault.invalidDate,null);
//			} catch (NullResultExeption e) {
//				//e.printStackTrace();
//				return new BooleanResponse(Fault.notFound,null);
//			} catch (NullInputExeption e) {
//				//e.printStackTrace();
//				return new BooleanResponse(Fault.requiredParameterNull,null);
//			} /*finally {
//				if (!(conn==null) && !conn.isClosed()) { conn.close(); }
//			}*/
//			
//    	
//    	
//    }*/
//    private static final String toDoubleDigit(int i) {
//    	if (i<10) {
//    		return "0"+Integer.toString(i);
//    	}
//    	return Integer.toString(i);
//    }
//
//    /*private ResultSet doQuery(PreparedStatement stmt, QueryParam query) throws SQLException, NullResultExeption  {
//    	System.out.println("queryparam"+query.getCurrency()+query.getLocation()+query.getYear());
//    	System.out.println("contains "+CACHE.containsKey(query));
//    	if (CACHE.containsKey(query)) {
//    		System.out.println("REadcache");
//    		return CACHE.get(query);
//    	}
//    	stmt.setString(1, query.getCurrency());
//		String loc;
//		if (query.getLocation()==EMPTY_STRING || query.getLocation()== null) {
//			loc=NOLOC_FLAG;
//		} else {
//			loc=query.getLocation();
//		}
//	
//		stmt.setString(2, loc);
//		stmt.setString(3, Integer.toString(query.getYear()));
//		ResultSet result= stmt.executeQuery();
//		System.out.println(counter++);
//		if (result.next())
//		{
//			System.out.println("Writecache");
//			CACHE.put(query, result);
//			return result;
//		}
//		throw new NullResultExeption(RESULT_NULL_EXEPTION);
//    	
//    }*/
//    private Map<String,Boolean> doQuery(PreparedStatement stmt, QueryParam query) throws SQLException, NullResultExeption  {
//    	//System.out.println("queryparam"+query.getCurrency()+query.getLocation()+query.getYear());
//    	//System.out.println("contains "+CACHE.containsKey(query));
//    	if (CACHE.containsKey(query)) {
//    		//System.out.println("REadcache");
//    		return CACHE.get(query);
//    	}
//    	stmt.setString(1, query.getCurrency());
//		String loc;
//		if (query.getLocation()==EMPTY_STRING || query.getLocation()== null) {
//			loc=NOLOC_FLAG;
//		} else {
//			loc=query.getLocation();
//		}
//	
//		stmt.setString(2, loc);
//		stmt.setString(3, Integer.toString(query.getYear()));
//		ResultSet result= stmt.executeQuery();
//		ResultSetMetaData metaData = result.getMetaData();
//		System.out.println(counter++);
//		if (result.next())
//		{
//			Map<String,Boolean> li=new HashMap<String,Boolean>();
//			int i=0;
//			for (i=result.findColumn(FIRSTDAYCOLUMNAME); i<=result.findColumn("DGDE31"); i++) {
//				//System.out.println("dayindex: "+i);
//				Character str = result.getString(i).charAt(0);
//				boolean res=false;
//				if (!(str==null)) {
//					res=str.equals(TRUE_FLAG);
//				}
//				//System.out.println(str);
//				li.put(metaData.getColumnName(i),res);
//			}
//			//System.out.println(result.getString("DGDE31")+str);
//			
//			//System.out.println("Writecache Last column"+ result.getMetaData().getColumnName(i));
//			CACHE.put(query, li);
//			return li;
//		}
//		throw new NullResultExeption(RESULT_NULL_EXEPTION);
//    	
//    }
//    /*private boolean parseResult(List<Character> result, int dayOfYear) {
//			//System.out.println("colum: "+columnname);
//    		dayOfYear--;
//    	 	Character rs=result.get(dayOfYear);
//			//System.out.println("res: "+rs+rs.getClass()+" "+dayOfYear);
//		if (rs==null) {
//			return false;
//		} else { 
//			return rs.equals(TRUE_FLAG);
//		}
//    }*/
//    private boolean parseResult(Map<String,Boolean> result, int month, int dayOfMonth) {
//		return result.get(DAYCOLUMN_CONST+MONTHMAP.get(month)+toDoubleDigit(dayOfMonth));
//		//System.out.println("colum: "+columnname);
//    	
//    	
//	}
//    @WebMethod
//    public BooleanResponse[] areHolidays(Holiday[] holidays) throws Exception {
//    	if (holidays==null || holidays.length==0) {
//			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
//		}
//    	
//			Connection conn= getDBConnect();
//			PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//			List<BooleanResponse> resultlist=new ArrayList<BooleanResponse>();
//			for (Holiday holiday : holidays) {
//				try {
//					checkNullHoliday(holiday);
//					Calendar cal= Calendar.getInstance();
//					SDF.setCalendar(cal);
//					cal.setTime(SDF.parse(holiday.getDate()));
//					QueryParam queryparam= new QueryParam(holiday.getCurrency(),holiday.getLocation(),cal.get(Calendar.YEAR));
//					resultlist.add(new BooleanResponse(Fault.success,parseResult(doQuery(stmt, queryparam), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))));
//				} catch (ParseException e) {
//					//e.printStackTrace();
//					resultlist.add(new BooleanResponse(Fault.invalidDate,null));
//					
//				} catch (NullResultExeption e) {
//					//e.printStackTrace();
//					resultlist.add(new BooleanResponse(Fault.notFound,null));
//				} catch (NullInputExeption e) {
//					//e.printStackTrace();
//					resultlist.add(new BooleanResponse(Fault.requiredParameterNull,null));
//				}
//
//			}
//			//stmt.close();
//			//conn.close();
//			return resultlist.toArray(new BooleanResponse[resultlist.size()]);
//    }
//    private DateResponse getNonHoliday(Holiday holiday,PreparedStatement stmt, boolean next) throws SQLException {
//    	Calendar cal= Calendar.getInstance();
//    	SDF.setCalendar(cal);
//    	try {
//			checkNullHoliday(holiday);
//			cal.setTime(SDF.parse(holiday.getDate()));
//			QueryParam queryparam= new QueryParam(holiday.getCurrency(),holiday.getLocation(),cal.get(Calendar.YEAR));
//			Map<String, Boolean> rs=doQuery(stmt, queryparam);
//			boolean result=parseResult(rs,cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
//			int year=cal.get(Calendar.YEAR);
//			
//			//boolean result=getBoolean(holiday,stmt);
//			while (result) {
//				 cal.add(Calendar.DAY_OF_YEAR, next ? 1: -1);
//				 if (!(cal.get(Calendar.YEAR)==year)) {
//					 queryparam= new QueryParam(holiday.getCurrency(),holiday.getLocation(),cal.get(Calendar.YEAR));
//					 rs=doQuery(stmt, queryparam);
//					 year=cal.get(Calendar.YEAR);
//				 }
//				 result=parseResult(rs,cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
//				// result=getBoolean(holiday, stmt);
//			}
//		} catch (NullInputExeption e) {
//			//e.printStackTrace();
//			return new DateResponse(Fault.requiredParameterNull,null);
//			
//		} catch (ParseException e) {
//			//e.printStackTrace();
//			return new DateResponse(Fault.invalidDate,null);
//		} catch (NullResultExeption e) {
//			//e.printStackTrace();
//			return new DateResponse(Fault.notFound,null);
//		}
//    	return new DateResponse(Fault.success,cal.getTime());
//    }
//    @WebMethod
//    public DateResponse getNextNonHoliday(Holiday holiday) throws Exception {
//			Connection conn= getDBConnect();
//			PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//			DateResponse result = getNonHoliday(holiday, stmt, true);
//			//stmt.close();
//			//conn.close();
//    	return result;
//    }
//    @WebMethod()
//    public DateResponse getPrevNonHoliday(Holiday holiday) throws Exception {
//    	Connection conn= getDBConnect();
//    	PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//    	DateResponse result=getNonHoliday(holiday, stmt, false);
//    	//stmt.close();
//    	//conn.close();
//    	return result;
//    }
//    @WebMethod
//    public DateResponse[] getNextNNonHoliday(Holiday[] holidays) throws Exception {
//    	if (holidays==null || holidays.length==0) {
//			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
//		}
//    	Connection conn= getDBConnect();
//    	PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//    	List<DateResponse> result=new ArrayList<DateResponse>();
//    	for (Holiday holiday : holidays) {
//    		result.add(getNonHoliday(holiday, stmt, true));
//		}
//    	//stmt.close();
//    	//conn.close();
//    	return result.toArray(new DateResponse[result.size()]);
//    	//return result;
//    }
//    @WebMethod
//    public DateResponse[] getPrevNNonHoliday(Holiday[] holidays) throws Exception {
//    	if (holidays==null  || holidays.length==0) {
//			throw new IllegalArgumentException(INPUT_NULL_EXEPTION);
//		}
//    	Connection conn= getDBConnect();
//    	PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
//    	List<DateResponse> result=new ArrayList<DateResponse>();
//    	for (Holiday holiday : holidays) {
//    		result.add(getNonHoliday(holiday, stmt, false));
//		}
//    	//stmt.close();
//    	//conn.close();
//    	return result.toArray(new DateResponse[result.size()]);
//    }
//    
//    public static void main(String[] args) {
////    	/*try {
////			System.out.println("gfgfg"+getDBConnect().);
////		} catch (SQLException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}*/
////    	Calendar cal= Calendar.getInstance();
////    	cal.setLenient(false);
////    	cal.set(1999, 11, 31);
////    	//new Date("2000.01.01");
////    	//System.out.println(cal.get(Calendar.DAY_OF_MONTH));
////    	MidasHolidays hejb=new MidasHolidays();
////    	Holiday[] hgf= {new Holiday("CAD",null,"2001-12-11"), new Holiday("CAD",null,"2001-12-11"), new Holiday("EUR","ATS","2000-03-04")};
////    	try {
////    		BooleanResponse lol= hejb.isHoliday(new Holiday("CAD",null,"2000-01-"));
////    		System.out.println(lol.getFault()+"ff "+lol.isResponse());
////    		/*for (boolean bum : hejb.areHolidays(hgf)) {
////				System.out.println("eredm�ny:"+bum);
////			} ;
////			System.out.println("nemnonos: "+hejb.getNextNonHoliday(new Holiday("CAD",null,cal)).get(Calendar.DAY_OF_YEAR));*/
////    		//System.out.println("els� munkanap: "+hejb.getPrevNonHoliday(new Holiday("CAD",null,"2000-01-03")).getDate());
////    		/*System.out.println("ezek: "+cal.get(Calendar.MONTH));
////    		System.out.println(cal.getTime().toGMTString());
////    		cal.add(Calendar.DAY_OF_YEAR, 1);
////    		System.out.println(cal.getTime().toGMTString());*/
////    	} catch (Exception e) {
////    		// TODO Auto-generated catch block
////    		e.printStackTrace();
////    	}
////	
///*    	try {
//			System.out.println( hejb.areHolidays(hgf));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}*/
//    	/*String curr="CAD";
//    	String loc="XAT";
//    	String datum="CAD";
//    	Holiday dolog= new Holiday(curr,loc,datum);
//        Holiday dolog2= new Holiday(curr,loc,datum);
//        Holiday dolog3= new Holiday("CA3",null,datum);
//        System.out.println(dolog.hashCode()+"  "+dolog2.hashCode()+"  "+dolog3.hashCode());*/
//    }
//    
//    
//
//}
