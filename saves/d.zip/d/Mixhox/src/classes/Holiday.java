package classes;

import java.io.Serializable;

public class Holiday implements Serializable {
	private static final long serialVersionUID = 3449783984579219739L;
	private String currency;
	private String location;
	private String date;
	
	public Holiday(String currency, String location, String date) {
		this.currency = currency;
		this.location = location;
		this.date=date;
	}
	

	public Holiday() {
	}


	public final String getCurrency() {
		return currency;
	}
	

	public final void setCurrency(String currency) {
		this.currency = currency;
	}


	public final void setLocation(String location) {
		this.location = location;
	}


	public final String getLocation() {
		return location;
	}


	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	
}
