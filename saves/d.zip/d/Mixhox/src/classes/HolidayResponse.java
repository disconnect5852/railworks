package classes;


public abstract class HolidayResponse {
	public enum Fault {
		requiredParameterNull, notFound, invalidDate, success
	}
	private Fault status;
	
	public HolidayResponse(Fault status) {
		super();
		this.status = status;
	}
	
	public HolidayResponse() {
	}

	public final Fault getStatus() {
		return status;
	}

	public final void setStatus(Fault status) {
		this.status = status;
	}
	
	
	
	
}
