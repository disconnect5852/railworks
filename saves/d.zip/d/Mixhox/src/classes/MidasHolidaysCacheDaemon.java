package classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MidasHolidaysCacheDaemon extends Thread {
	private static MidasHolidaysCacheDaemon INSTANCE=null;
	private static Map<QueryParam, Map<String,Boolean>> CACHE=Collections.synchronizedMap(new HashMap<QueryParam, Map<String,Boolean>>());
	private static DataSource DATASOURCE=null;
	private static final String SQL_QUERY_ISHOLIDAY="SELECT * FROM SDHOLPD";
	private static final String SQL_QUERY_REFRESHCACHE="SELECT DGCYCD,DGLCCD,DGYRNB,DGLCD FROM SDHOLPD";
	private static final char TRUE_FLAG='X';
	private static final String FIRSTDAYCOLUMNAME="DGJA01";
	private static final String LASTDAYCOLUMNAME="DGDE31";
	private static final String CURRENCY_COLUMN= "DGCYCD";
	private static final String LOCATION_COLUMN= "DGLCCD";
	private static final String YEAR_COLUMN= "DGYRNB";
	private static final String LAST_CHANGE= "DGLCD";
	private static final long THREAD_SLEEP_TIME=60000;
	//private static final ResourceBundle PROPERTIES=ResourceBundle.getBundle("resources.jdbc");
	public static final MidasHolidaysCacheDaemon getInstance() throws NamingException {
		if (INSTANCE==null) {
			INSTANCE= new MidasHolidaysCacheDaemon();
			try {
				try {
					INSTANCE.fillCache();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return INSTANCE;
	}
	
	private MidasHolidaysCacheDaemon() throws NamingException {
		start();
		System.out.println("----------------------------cratedaemon");
		try {
			Context ctx= new InitialContext();
			DATASOURCE=(DataSource)ctx.lookup("jdbc/midasv8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Map<QueryParam, Map<String,Boolean>> getCache() {
		return CACHE;
	}
	/*private final Connection getDBConnect() throws ClassNotFoundException, SQLException{
		Connection conn=null;
			System.out.println("Params"+PROPERTIES.getString("driverClass")+" "+PROPERTIES.getString("connectionURL"));
			Class.forName(PROPERTIES.getString("driverClass"));
			conn=DriverManager.getConnection(PROPERTIES.getString("connectionURL"),PROPERTIES.getString("username"),PROPERTIES.getString("password"));
			return conn;
	}*/
	
	private void fillCache() throws SQLException, ClassNotFoundException {
		System.out.println("fillcache run");
		Connection conn=  /*getDBConnect();*/ DATASOURCE.getConnection();
		PreparedStatement stmt= conn.prepareStatement(SQL_QUERY_ISHOLIDAY);
		ResultSet result= stmt.executeQuery();
		ResultSetMetaData metaData = result.getMetaData();
		while (result.next()) {
			Map<String,Boolean> li=new HashMap<String,Boolean>();
			for (int i=result.findColumn(FIRSTDAYCOLUMNAME); i<=result.findColumn(LASTDAYCOLUMNAME); i++) {
				Character str = result.getString(i).charAt(0);
				boolean res=false;
				if (!(str==null)) {
					res=str.equals(TRUE_FLAG);
				}
				li.put(metaData.getColumnName(i),res);
			}
			QueryParam key = new QueryParam(result.getString(CURRENCY_COLUMN),result.getString(LOCATION_COLUMN), Integer.parseInt(result.getString(YEAR_COLUMN)),result.getInt(LAST_CHANGE) );
			System.out.println("inputqueryparam"+key.getCurrency()+key.getLocation()+key.getYear());
			CACHE.put(key , li);
		}
		conn.close();
		System.out.println("end");
	}
	private void refreshCache() throws SQLException, ClassNotFoundException {
		CACHE.clear();
		fillCache();
		System.out.println( CACHE.size());
	}
	@Override
	public void run() {
		while (true) {
				try {
					sleep(THREAD_SLEEP_TIME);
					refreshCache();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	/*public static void main(String[] args) {
		try {
				MidasHolidaysCacheDaemon dm= getInstance();

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}
