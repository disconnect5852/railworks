package classes;

import java.util.Date;

public class DateResponse extends HolidayResponse {
	private Date response;
	

	public DateResponse(Fault fault, Date response) {
		super(fault);
		this.response = response;
	}
	

	public DateResponse() {
		super();
	}


	public final Date getResponse() {
		return response;
	}

	public final void setResponse(Date response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "Resp: "+response;
	}
	


}
