package classes;

import ws.MidasHolidays;

public class QueryParam {
	private String currency;
	private String location;
	private int year;
	private int last_change_date;
	public QueryParam(String currency, String location, int year, int last_change_date) {
		this.currency = currency;
		this.location = location==null ? MidasHolidays.NOLOCATION_FLAG: location;
		this.year = year;
		this.last_change_date=last_change_date;
	}
	
	public final int getLast_change_date() {
		return last_change_date;
	}

	public final void setLast_change_date(int last_change_date) {
		this.last_change_date = last_change_date;
	}

	public final String getCurrency() {
		return currency;
	}
	public final void setCurrency(String currency) {
		this.currency = currency;
	}
	public final String getLocation() {
		return location;
	}
	public final void setLocation(String location) {
		this.location = location;
	}
	public final int getYear() {
		return year;
	}
	public final void setYear(int year) {
		this.year = year;
	}
	@Override
	public boolean equals(Object o) {
		QueryParam param= (QueryParam) o;
		return ( currency.equals(param.currency) && location.equals(param.location)   && year==param.year );
	}
	@Override
	public int hashCode() {
		return currency.hashCode()+location.hashCode()+year;
	}
	
	
}
