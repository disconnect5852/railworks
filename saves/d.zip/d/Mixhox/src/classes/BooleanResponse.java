package classes;


public class BooleanResponse extends HolidayResponse {
	private Boolean response;

	public BooleanResponse(Fault fault, Boolean response) {
		super(fault);
		this.response = response;
	}
	

	public BooleanResponse() {
		super();
	}


	public final Boolean isResponse() {
		return response;
	}

	public final void setResponse(Boolean response) {
		this.response = response;
	}


	@Override
	public String toString() {
		return "Resp: "+response.toString();
	}
	
	
}
