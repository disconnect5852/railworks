package classes;

public class CacheData {
	boolean data;
	int lastChangeDate_DGLCD;
	public final boolean isData() {
		return data;
	}
	public final void setData(boolean data) {
		this.data = data;
	}
	public final int getLastChangeDate_DGLCD() {
		return lastChangeDate_DGLCD;
	}
	public final void setLastChangeDate_DGLCD(int lastChangeDate_DGLCD) {
		this.lastChangeDate_DGLCD = lastChangeDate_DGLCD;
	}
	
}
