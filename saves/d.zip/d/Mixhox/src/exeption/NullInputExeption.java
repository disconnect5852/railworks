package exeption;

public class NullInputExeption extends Exception {

	private static final long serialVersionUID = -2163274793462498608L;

	public NullInputExeption() {
		super();
	}

	

}
