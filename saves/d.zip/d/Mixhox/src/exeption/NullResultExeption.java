package exeption;

public class NullResultExeption extends Exception {

	private static final long serialVersionUID = -5484633558867250941L;

	public NullResultExeption() {
		super();
	}

	public NullResultExeption(String message) {
		super(message);
	}
	
}
